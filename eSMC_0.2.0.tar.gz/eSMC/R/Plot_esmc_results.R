#' Plots results from eSMC
#'
#' @param results : results output from eSMC (separate real results from those of the pseudo-observed data if check of eSMC was TRUE)
#' @param mu : mutation rate per site per generation
#' @param WP : TRUE to write pdf
#' @param path : location to print pdf
#' @param LIST : TRUE if results is a list of eSMC results, false if results is an output from eSMC
#' @param x : generations ago bondaries
#' @param y : logarithmic boundaries in base 10 of the population size
#' @param title : title of the plot
#' @param x_sim : time in generation of the simulated data
#' @param y_sim : population size of the simulated data
#' @param check : TRUE if check was TRUE when running eSMC, FALSE if check was FALSE when running eSMC
#' @export
#' @return A pdf or display plot in R
Plot_esmc_results<-function(results,mu,WP=T,path=NA,LIST=F,x=c(1,10^7),y=c(2,8),title="Demographic history",x_sim=NA,y_sim=NA,check=F){
  if(!is.na(x_sim)&!is.na(y_sim)){
    if(length(x_sim)==length(y_sim)){
      sim=T
    } else {
      sim=F
      }
  }else{
    sim=F
  }
    if(is.na(path)){
    path="plot_esmc.pdf"
    }
  if(!check){
    if(!LIST){
      if(WP){
        grDevices::pdf(path)
        graphics::plot(x,c(1,1), log=c("x"), ylim =y ,type="n", xlab= paste("Generations ago",sep=" "), ylab="population size (log10)")
        Pop_=results$mu/mu
        graphics::lines((results$Tc*Pop_), log10((as.numeric(results$Xi))*Pop_), type="s", col="red")
        if(sim){graphics::lines(x_sim,y_sim, type="s", col="black")}
        title(title,adj = 0)
        grDevices::dev.off()
      }
      if(!WP){
        graphics::plot(x,c(1,1), log=c("x"), ylim =y ,type="n", xlab= paste("Generations ago",sep=" "), ylab="population size (log10)")
        Pop_=results$mu/mu
        graphics::lines((results$Tc*Pop_), log10((as.numeric(results$Xi))*Pop_), type="s", col="red")
        title(title,adj = 0)
        if(sim){graphics::lines(x_sim,y_sim, type="s", col="black")}
      }
    }
    if(LIST){
      if(WP){
        grDevices::pdf(path)
        graphics::plot(x,c(1,1), log=c("x"), ylim =y ,type="n", xlab= paste("Generations ago",sep=" "), ylab="population size (log10)")
        for(i in 1:length(results)){
          Pop_=results[[i]]$mu/mu
          graphics::lines((results[[i]]$Tc*Pop_), log10((as.numeric(results[[i]]$Xi))*Pop_), type="s", col="red")
        }
        title(title,adj = 0)
        if(sim){graphics::lines(x_sim,y_sim, type="s", col="black")}
        grDevices::dev.off()
      }
      if(!WP){
        graphics::plot(x,c(1,1), log=c("x"), ylim =y ,type="n", xlab= paste("Generations ago",sep=" "), ylab="population size (log10)")
        for(i in 1:length(results)){
          Pop_=results[[i]]$mu/mu
          graphics::lines((results[[i]]$Tc*Pop_), log10((as.numeric(results[[i]]$Xi))*Pop_), type="s", col="red")
        }
        if(sim){graphics::lines(x_sim,y_sim, type="s", col="black")}
        title(title,adj = 0)
      }
    }
  }
  if(check){
    if(!LIST){
      if(WP){
        grDevices::pdf(path)
        graphics::plot(x,c(1,1), log=c("x"), ylim =y ,type="n", xlab= paste("Generations ago",sep=" "), ylab="population size (log10)")
        Pop_=results[[1]]$mu/mu
        graphics::lines((results[[1]]$Tc*Pop_), log10((as.numeric(results[[1]]$Xi))*Pop_), type="s", col="red")
        if(sim){graphics::lines(x_sim,y_sim, type="s", col="black")}
        title(title,adj = 0)

        graphics::plot(x,c(1,1), log=c("x"), ylim =y ,type="n", xlab= paste("Generations ago",sep=" "), ylab="population size (log10)")
        Pop_=results[[2]]$mu/mu
        graphics::lines((results[[2]]$Tc*Pop_), log10((as.numeric(results[[2]]$Xi))*Pop_), type="s", col="red")
        if(sim){graphics::lines(x_sim,y_sim, type="s", col="black")}
        title(paste(title,"Simulated",sep=" "),adj = 0)

        grDevices::dev.off()
      }
      if(!WP){
        graphics::plot(x,c(1,1), log=c("x"), ylim =y ,type="n", xlab= paste("Generations ago",sep=" "), ylab="population size (log10)")
        Pop_=results[[1]]$mu/mu
        graphics::lines((results[[1]]$Tc*Pop_), log10((as.numeric(results[[1]]$Xi))*Pop_), type="s", col="red")
        if(sim){graphics::lines(x_sim,y_sim, type="s", col="black")}
        title(title,adj = 0)

        graphics::plot(x,c(1,1), log=c("x"), ylim =y ,type="n", xlab= paste("Generations ago",sep=" "), ylab="population size (log10)")
        Pop_=results[[2]]$mu/mu
        graphics::lines((results[[2]]$Tc*Pop_), log10((as.numeric(results[[2]]$Xi))*Pop_), type="s", col="red")
        if(sim){graphics::lines(x_sim,y_sim, type="s", col="black")}
        title(paste(title,"Simulated",sep=" "),adj = 0)


      }
    }
    if(LIST){
      if(WP){
        grDevices::pdf(path)
        graphics::plot(x,c(1,1), log=c("x"), ylim =y ,type="n", xlab= paste("Generations ago",sep=" "), ylab="population size (log10)")
        for(i in 1:length(results)){
          Pop_=results[[i]][[1]]$mu/mu
          graphics::lines((results[[i]][[1]]$Tc*Pop_), log10((as.numeric(results[[i]][[1]]$Xi))*Pop_), type="s", col="red")
        }
        title(title,adj = 0)
        if(sim){graphics::lines(x_sim,y_sim, type="s", col="black")}

        graphics::plot(x,c(1,1), log=c("x"), ylim =y ,type="n", xlab= paste("Generations ago",sep=" "), ylab="population size (log10)")
        for(i in 1:length(results)){
          Pop_=results[[i]][[1]]$mu/mu
          graphics::lines((results[[i]][[1]]$Tc*Pop_), log10((as.numeric(results[[i]][[1]]$Xi))*Pop_), type="s", col="red")
        }
        if(sim){graphics::lines(x_sim,y_sim, type="s", col="black")}
        title(paste(title,"Simulated",sep=" "),adj = 0)
        grDevices::dev.off()
      }
      if(!WP){
        graphics::plot(x,c(1,1), log=c("x"), ylim =y ,type="n", xlab= paste("Generations ago",sep=" "), ylab="population size (log10)")
        for(i in 1:length(results)){
          Pop_=results[[i]][[1]]$mu/mu
          graphics::lines((results[[i]][[1]]$Tc*Pop_), log10((as.numeric(results[[i]][[1]]$Xi))*Pop_), type="s", col="red")
        }
        title(title,adj = 0)
        if(sim){graphics::lines(x_sim,y_sim, type="s", col="black")}

        graphics::plot(x,c(1,1), log=c("x"), ylim =y ,type="n", xlab= paste("Generations ago",sep=" "), ylab="population size (log10)")
        for(i in 1:length(results)){
          Pop_=results[[i]][[1]]$mu/mu
          graphics::lines((results[[i]][[1]]$Tc*Pop_), log10((as.numeric(results[[i]][[1]]$Xi))*Pop_), type="s", col="red")
        }
        if(sim){graphics::lines(x_sim,y_sim, type="s", col="black")}
        title(paste(title,"Simulated",sep=" "),adj = 0)
      }
    }
  }
}
