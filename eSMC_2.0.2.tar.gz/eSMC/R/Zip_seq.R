#'  Builds a zip signal from the symbol matrix
#'
#' @param Os : original signal (sequence of 0 and 1)
#' @param Mat_symbol : Symbol matrix with the zipping pattern
#' @return A list with first object the ziped sequence, as second the symbol matrix
Zip_seq<-function(Os,Mat_symbol){
  ini=Os[1]
  Os=Os[-1]
  output=list()
  for(zip_o in 1:2){
    count=0
    criteria=T
    l=vector()
    if(length(as.numeric(Mat_symbol[[zip_o]]))>0){
      for(jj in 1:dim(Mat_symbol[[zip_o]])[1]){
        count=count+1
        new_symbol= Mat_symbol[[zip_o]][jj,1]
        L=length(Os)

        rep_symbol= Mat_symbol[[zip_o]][jj,2]
        pos_s=gregexpr(rep_symbol,paste(as.character(Os),collapse = ""))
        pos_s=as.vector(as.matrix(pos_s[[1]]))

        if(length(pos_s)>1){
          Os[pos_s]=new_symbol
          pos_s=pos_s+1
          Os=Os[-pos_s]
        }
        rm(pos_s)
      }
    }
  }
  Os=c(ini,Os)
  #output[[1]]=Os
  #output[[2]]=Mat_symbol
  return(list(Os,Mat_symbol))
}
