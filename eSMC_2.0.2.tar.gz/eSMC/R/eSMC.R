#' Runs the ecological Sequentially Markovian Coalescent
#'
#' Runs the eSMC to estimate demographic history and ecological parameters
#' @param n : Number of hidden states
#' @param rho : prior ratio of recombination over mutation
#' @param O : Segregating site matrix (or list of segregating site matrix to use more than one chromosome/scaffold)
#' @param maxit : maximum number of iteration for the baum_welch algorithm
#' @param BoxB : boundaries of the germination rate ( first value must be  bigger than 0)
#' @param BoxP : logarithmic boundaries in base 10 for the  demography e.g. c(3,3) means the  population size can grow up to a thousand time  and decrease up to a thousand time
#' @param Boxr : logarithmic boundaries in base 10 for the  recombination rate e.g. c(1,1) means the recombination rate can be up to ten times smaller or bigger than the initial given value
#' @param Boxs : boundaries for the self-fertilization rate e.g. c(0.5,0.9) means the selfing rate is between 0.5 and 0.9
#' @param pop : True if population size is assumed constant
#' @param SB : True to estimate germination rate
#' @param SF : True to estimate Self-fertilization rate
#' @param Rho : True to estimate recombination rate
#' @param Check : True to simulate data based on result and run eSMC on this simulation
#' @param BW : True to use the complete implementation of the Baum-Welch algorithm
#' @param NC : Number of chromosome or scaffold (must be equal of the size of the list is O is a list of Segregating site matrix)
#' @param pop_vect : vector of hidden state sharing their population size parameter. Sum must be equal to hidden state number
#' @param path_simu : path to scrm executable e.g. "~/Document"
#' @param sigma : initial value for self-fertilization rate
#' @param beta : initial value for germination rate
#' @param Share_r : TRUE if all chromosome/scaffold have same recombination rate
#' @export
#' @return A list containing all estimation if check is FALSE. If check is TRUE then output is a list of two list containing all estimation (first list contains estimation based on the data second on the pseudo-observed data). List of results contain:LH the likelihood, Tc the expected coalescent time,L length of the sequence, rho the recombination rate,mu the mutation rate, beta the germination rate, sigma the self-fertilization rate, Xi the vector of change of population size (population size at time t is  Xi[t]*Ne),Os the date used.
eSMC<-function(n=40,rho=1,O,maxit =20,BoxB=c(0.05,1),BoxP=c(3,3),Boxr=c(1,1),Boxs=c(0,0.99),pop=F,SB=F,SF=F,Rho=T,Check=F,BW=F,NC=1,pop_vect=NA,path_simu="~/Documents/escrm/",sigma=0,beta=1,Share_r=T){
  gamma=rho
  sigma=max(Boxs[1],sigma)
  sigma=min(Boxs[2],sigma)
  beta=min(BoxB[2],beta)
  beta=max(BoxB[1],beta)
  if(NC==1){
    Share_r=T
  }
  if(SF|SB){
    BaWe=2
  }else{
    BaWe=1
  }
  if(any(is.na(pop_vect))){
    n=2*floor((n*0.5))
    pop_vect=rep(2,(n*0.5))
  }

  if(NC==1){
    M=dim(O)[1]-2
    L=as.numeric(O[(M+2),dim(O)[2]])
    Os=list()
    count=0
    theta_W=0
    s=dim(O)[1]
    for(k in 1:(M-1)){
      for(l in (k+1):M){
        Os_=seqSNP2_MH(O[c(k,l,(s-1),s),],L)
        if((Os_$theta)>=2){#
          count=count+1
          print(k)
          print(l)
          print(Os_$theta)
          theta_W=theta_W+(Os_$theta)
          if(count==1){
            if(L<=10^6){
              Os[[count]]=Build_zip_ID_2seq(Os_$seq)
              Mat_symbol=Os[[count]][[2]]
            }else{
              Os_temp=Build_zip_ID_2seq(Os_$seq[1:(10^6)])
              Mat_symbol=Os_temp[[2]]
              rm(Os_temp)
              Os[[count]]=Zip_seq(Os_$seq,Mat_symbol)
            }
          }
          if(count>1){
            Os[[count]]=Zip_seq(Os_$seq,Mat_symbol)
          }
          Os[[count]]=symbol2Num(Os[[count]][[1]],Os[[count]][[2]])
        }
      }
    }
    if(length(Os)>=1){
      theta_W=theta_W/length(Os)
      theta=theta_W*(beta*beta)*2/(2-sigma)
      mu=theta/(2*L)
      rho=rho*theta
      O=Os
      rm(Os_)
    }
    if(length(Os)==0){
      stop("data too poor")
    }
    rm(Os)

  }
  if(NC>1){
    if(length(O)!=NC){
      stop("Not good number of chromosome given")
    }
    Os=list()
    theta_W_V=vector(length=NC)
    L_total=vector()
    start_zip=T
    NC_c=vector()
    for(chr in 1:NC){
      theta_W=0
      count=0
      OST_=list()
      M=(dim(O[[chr]])[1]-2)
      L=as.numeric(O[[chr]][(M+2),dim(O[[chr]])[2]])
      L_total=c(L_total,L)
      for(k in 1:(M-1)){
        for(l in (k+1):M){
          s=dim(O[[chr]])[1]
          Os_=seqSNP2_MH(O[[chr]][c(k,l,(s-1),s),],L)
          if((Os_$theta)>=2){
            count=count+1
            theta_W=theta_W+(Os_$theta)
            if(count==1&start_zip){
              if(L<=10^6){
                OST_[[count]]=Build_zip_ID_2seq(Os_$seq)
                Mat_symbol=OST_[[count]][[2]]

              }else{
                Os_temp=Build_zip_ID_2seq(Os_$seq[1:(10^6)])
                Mat_symbol=Os_temp[[2]]
                rm(Os_temp)
                OST_[[count]]=Zip_seq(Os_$seq,Mat_symbol)
              }
              start_zip=F
            }
            if(count>1|chr>1){
              OST_[[count]]=Zip_seq(Os_$seq,Mat_symbol)
            }
            OST_[[count]]=symbol2Num(OST_[[count]][[1]],OST_[[count]][[2]])
          }
        }
      }
      rm(Os_)
      if(theta_W>=1){
      NC_c=c(NC_c,chr)
      Os[[length(NC_c)]]=OST_
      theta_W=theta_W/length(OST_)
      theta_W_V[chr]=theta_W
}
      rm(OST_)
    }
    theta_W_V=theta_W_V[NC_c]
    NC=length(NC_c)
    if(length(rho)>1){
      rho=rho[NC_c]
    }
    theta=theta_W_V*(beta*beta)*2/(2-sigma)
    mu=theta/(2*L_total)
    rho=rho*theta
    O=Os
    L=L_total
    rm(Os)
    theta_W=theta_W_V
  }
  if(length(O)>=1){
    print("theta estimation")
    print(theta_W)
    if(BaWe==1){
      if(Rho){
        results=Baum_Welch_algo(Os=O, maxIt =maxit,L=L,mu=mu,theta_W =theta_W,Rho=rho,beta=beta,sigma=sigma,Popfix=pop,SB=SB,SF=SF,k=n,BoxB=BoxB,BoxP=BoxP,Boxr=Boxr,Boxs = Boxs,maxBit = 1,pop_vect=pop_vect,ER=Rho,NC=NC,BW=BW,redo_R=T,Share_r=Share_r)
      }else{
        results=Baum_Welch_algo(Os=O, maxIt =maxit,L=L,mu=mu,theta_W =theta_W,Rho=rho,beta=beta,sigma=sigma,Popfix=pop,SB=SB,SF=SF,k=n,BoxB=BoxB,BoxP=BoxP,Boxr=Boxr,Boxs = Boxs,maxBit = 1,pop_vect=pop_vect,ER=Rho,NC=NC,BW=BW,redo_R=F,Share_r=Share_r)
      }
      }
    if(BaWe==2){
      rho=theta
      results=Baum_Welch_algo(Os=O, maxIt =maxit,L=L,mu=mu,theta_W=theta_W,Rho=rho,beta=beta,sigma=sigma,Popfix=pop,SB=F,SF=F,k=n,BoxB=BoxB,BoxP=BoxP,Boxr=c(1,1),Boxs =Boxs,maxBit = 1,pop_vect=pop_vect,ER=T,NC=NC,BW=BW,Share_r=Share_r)
      r=results$rho[1:NC]
      mu_=results$mu
      gamma_=r/mu_
      print("estimation of r/mu")
      print(mean(gamma_))
      if(mean(gamma_)>1){
        print("Results might not be reliable")
      }
      effect=mean(gamma_/gamma)
      print("effect")
      print(effect)
      if(SF&!SB){
        sigma=(1-effect)/(1-(effect/2))
        sigma=max(Boxs[1],sigma)
        sigma=min(Boxs[2],sigma)

      }
      if(SB&!SF){
        beta=effect
        beta=min(BoxB[2],beta)
        beta=max(BoxB[1],beta)

      }
      if(SF&SB){
        if(min(BoxB)>(1-max(Boxs))){
          sigma=(1-(effect/beta))/(1-(effect/(2*beta)))
          sigma=max(Boxs[1],sigma)
          sigma=min(Boxs[2],sigma)
          beta=effect*(2-sigma)/(2*(1-sigma))
          beta=max(BoxB[1],beta)
          beta=min(BoxB[2],beta)
        }
        if(min(BoxB)<=(1-max(Boxs))){
          beta=effect*(2-sigma)/(2*(1-sigma))
          beta=max(BoxB[1],beta)
          beta=min(BoxB[2],beta)
          sigma=(1-(effect/beta))/(1-(effect/(2*beta)))
          sigma=max(Boxs[1],sigma)
          sigma=min(Boxs[2],sigma)
        }
        if(gamma_!=(gamma*beta*2*(1-sigma)/(2-sigma))){
          print("Prior might disagree with results.")
        }
      }
      theta=theta_W*(beta*beta)*2/(2-sigma)
      mu=theta/(2*L)
      rho=gamma*theta
      results=Baum_Welch_algo(Os=O, maxIt =maxit,L=L,mu=mu,theta_W =theta_W,Rho=rho,beta=beta,sigma=sigma,Popfix=pop,SB=SB,SF=SF,k=n,BoxB=BoxB,BoxP=BoxP,Boxr=Boxr,Boxs = Boxs,maxBit = 1,pop_vect=pop_vect,ER=Rho,NC=NC,BW=BW,Share_r=Share_r)
    }
  }
  if(!Check){
    return(results)
  }
  if(Check){
    results_o=results
    params=list()
    lr=1
    if(length(unique(gamma))>1){
      lr=NC
    }
    for(xx in 1:NC){

      chi=as.numeric(results$Xi)
      beta_s=results$beta
      sigma_s=results$sigma
      time_s=results$Tc
      L_s=L[xx]
      theta_s=theta_W[xx]
      if(Rho){
      if(Share_r){
        rho_s=mean(results$rho[xx]/results$mu)*theta_W[xx]
      }else{
        rho_s=(results$rho[xx]/results$mu[xx])*theta_W[xx]
      }
      }else{
        if(Share_r){
          rho_s=gamma*theta_W[xx]
        }else{
          rho_s=gamma[xx]*theta_W[xx]
        }
      }
      vect_p=c(M,theta_s,rho_s,L_s,beta_s,sigma_s,chi,time_s)
      params[[xx]]=vect_p
    }
    O=Build_simu(NC,n,params,path_simu)
    if(NC==1){
      O=O[[1]]
      M=dim(O)[1]-2
      L=as.numeric(O[(M+2),dim(O)[2]])
      Os=list()
      count=0
      theta_W=0
      s=dim(O)[1]
      for(k in 1:(M-1)){
        for(l in (k+1):M){
          Os_=seqSNP2_MH(O[c(k,l,(s-1),s),],L)
          if(Os_$theta>1){#
            count=count+1
            print(count)
            theta_W=theta_W+(Os_$theta)
            if(count==1){
              Os[[count]]=Build_zip_ID_2seq(Os_$seq)
              Mat_symbol=Os[[count]][[2]]
            }
            if(count>1){
              Os[[count]]=Zip_seq(Os_$seq,Mat_symbol)
            }
            Os[[count]]=symbol2Num(Os[[count]][[1]],Os[[count]][[2]])
          }
        }
      }
      if(length(Os)>=1){
        theta_W=theta_W/length(Os)
        theta=theta_W*(beta*beta)*2/(2-sigma)
        mu=theta/(2*L)
        rho=gamma*theta
        O=Os
        rm(Os_)
      }
      if(length(Os)==0){
        stop("data too poor")

      }
      rm(Os)

    }
    if(NC>1){
      if(length(O)!=NC){
        stop("Not good number of chromosome given")
      }
      Os=list()
      theta_W_V=vector(length=NC)
      L_total=vector()
      for(chr in 1:NC){
        theta_W=0
        count=0
        OST_=list()
        M=(dim(O[[chr]])[1]-2)
        L=as.numeric(O[[chr]][(M+2),dim(O[[chr]])[2]])
        L_total=c(L_total,L)

        for(k in 1:(M-1)){
          for(l in (k+1):M){
            s=dim(O[[chr]])[1]
            Os_=seqSNP2_MH(O[[chr]][c(k,l,(s-1),s),],L)
            if(Os_$theta>1){
              count=count+1
              print(count)
              theta_W=theta_W+(Os_$theta)
              if(count==1){
                OST_[[count]]=Build_zip_ID_2seq(Os_$seq)
                Mat_symbol=OST_[[count]][[2]]
              }
              if(count>1){
                OST_[[count]]=Zip_seq(Os_$seq,Mat_symbol)
              }
              OST_[[count]]=symbol2Num(OST_[[count]][[1]],OST_[[count]][[2]])
            }
          }
        }

        rm(Os_)
        Os[[chr]]=OST_
        theta_W=theta_W/length(OST_)
        theta_W_V[chr]=theta_W
        rm(OST_)
      }

      theta=theta_W_V*(beta*beta)*2/(2-sigma)
      mu=theta/(2*L_total)
      rho=gamma*theta
      O=Os
      L=L_total
      rm(Os)
      theta_W=theta_W_V
    }
    if(BaWe==1){
      if(Rho){
        results=Baum_Welch_algo(Os=O, maxIt =maxit,L=L,mu=mu,theta_W =theta_W,Rho=rho,beta=beta,sigma=sigma,Popfix=pop,SB=SB,SF=SF,k=n,BoxB=BoxB,BoxP=BoxP,Boxr=Boxr,Boxs = Boxs,maxBit = 1,pop_vect=pop_vect,ER=Rho,NC=NC,BW=BW,redo_R=T,Share_r=Share_r)

      }else{
        results=Baum_Welch_algo(Os=O, maxIt =maxit,L=L,mu=mu,theta_W =theta_W,Rho=rho,beta=beta,sigma=sigma,Popfix=pop,SB=SB,SF=SF,k=n,BoxB=BoxB,BoxP=BoxP,Boxr=Boxr,Boxs = Boxs,maxBit = 1,pop_vect=pop_vect,ER=Rho,NC=NC,BW=BW,redo_R=F,Share_r=Share_r)
      }
          }
    if(BaWe==2){
      rho=theta
      results=Baum_Welch_algo(Os=O, maxIt =maxit,L=L,mu=mu,theta_W =theta_W,Rho=rho,beta=beta,sigma=sigma,Popfix=pop,SB=F,SF=F,k=n,BoxB=BoxB,BoxP=BoxP,Boxr=c(1,1),Boxs =Boxs ,maxBit = 1,pop_vect=pop_vect,ER=T,NC=NC,BW=BW,Share_r=Share_r)
      if(SB|SF){
        r=results$rho[1:NC]
        mu_=results$mu
        gamma_=r/mu_
        print(r)
        print(mu_)
        print(gamma_)
        if(mean(gamma_)>1){
          print("Results might not be reliable")
        }
        effect=mean(gamma_/gamma)
        if(SF&!SB){
          sigma=(1-effect)/(1-(effect/2))
          sigma=max(Boxs[1],sigma)
          sigma=min(Boxs[2],sigma)
          if(sigma>=Boxs[1]&sigma<=Boxs[2]){
            Boxs[1]=sigma
          }
        }
        if(SB&!SF){
          beta=effect
          beta=min(BoxB[2],beta)
          beta=max(BoxB[1],beta)
          if(beta>=BoxB[1]&beta<=BoxB[2]){
            BoxB[2]=beta
          }
        }
        if(SF&SB){
          if(min(BoxB)>(1-max(Boxs))){
            sigma=(1-(effect/beta))/(1-(effect/(2*beta)))
            sigma=max(Boxs[1],sigma)
            sigma=min(Boxs[2],sigma)
            beta=effect*(2-sigma)/(2*(1-sigma))
            beta=max(BoxB[1],beta)
            beta=min(BoxB[2],beta)
          }
          if(min(BoxB)<=(1-max(Boxs))){
            beta=effect*(2-sigma)/(2*(1-sigma))
            beta=max(BoxB[1],beta)
            beta=min(BoxB[2],beta)
            sigma=(1-(effect/beta))/(1-(effect/(2*beta)))
            sigma=max(Boxs[1],sigma)
            sigma=min(Boxs[2],sigma)

          }
          if(gamma_!=(gamma*beta*2*(1-sigma)/(2-sigma))){
            print("Prior might disagree with results.")
          }
        }
      }
      theta=theta_W*(beta*beta)*2/(2-sigma)
      mu=theta/(2*L)
      rho=gamma*theta
      results=Baum_Welch_algo(Os=O, maxIt =maxit,L=L,mu=mu,theta_W =theta_W,Rho=rho,beta=beta,sigma=sigma,Popfix=pop,SB=SB,SF=SF,k=n,BoxB=BoxB,BoxP=BoxP,Boxr=Boxr,Boxs = Boxs,maxBit = 1,pop_vect=pop_vect,ER=Rho,NC=NC,BW=BW,Share_r=Share_r)
    }
    results_f=list()
    results_f[[1]]=results_o
    results_f[[2]]=results
    return(results_f)
  }
}
