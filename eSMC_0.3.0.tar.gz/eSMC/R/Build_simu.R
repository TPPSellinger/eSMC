#' Build simulation to check results
#'
#'  Build simulation from eSMC output to check if estimated scenario can be retrieve from prior
#' @param NC : Number of different chromosome or scaffold analyzed
#' @param n : number of hidden states
#' @param param : vector containing model parameters outputed by eSMC
#' @param path_scrm : location of the algorithm scrm
#' @return simulation results estimated under the estimated demographic history
Build_simu<-function(NC,n,param,path_scrm){
  O=list()
  for(chr in 1:NC){
    parameters=param[[chr]]
    M=parameters[1]
    theta=parameters[2]
    rho=parameters[3]
    L=parameters[4]
    beta=parameters[5]
    sigma=parameters[6]
    chi=parameters[7:(6+n)]
    time=parameters[(7+n):(6+n+n)]
    setwd(path_scrm)
    command_simu=paste("./scrm",M,1,"-t",theta,"-r",rho,L,sep=" ")
    for(x in 1:length(chi)){
      command_simu=paste(command_simu,"-eN",time[x],chi[x],sep=" ")
    }
    command_simu=paste(command_simu," -B 1",beta," -S 1",sigma,"> Check_simu.txt",sep=" ")
    system(command_simu)
    path=paste(path_scrm,"/Check_simu.txt",sep="")
    DNAseqfile=Get_data(path)
    O_total=Seqlist2data(DNAseqfile,L,M,1)
    O[[NC]]=O_total[[1]]
  }
  return(O)
}
