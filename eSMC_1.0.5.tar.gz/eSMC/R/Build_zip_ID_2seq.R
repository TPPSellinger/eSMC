#'  Zip the  signal to reduce signal length
#'
#' @param Os : original signal (sequence of 0 and 1)
#' @param max_count : maximum number of symbol
#' @return A list with first object the ziped sequence and as second the symbol matrix#
Build_zip_ID_2seq<-function(Os,max_count=20){
  ini=Os[1]
  Os=Os[-1]
  count=0
  output=list()
  criteria=T
  mat_symbol=vector()
  l=vector()
  while(criteria){
    count=count+1
    if(count<9){
      new_symbol=1+count
    }
    if(count>8& (count-8)<27){
      new_symbol=letters[count-8]
    }
    if((count-8)>=27){
      criteria=F
    }
    if((count-8)<27){
      L=length(Os)
      if(count==1){
        symbol_base=c("0")
      }
      symbol=vector()
      for(sb1 in 1:length(symbol_base)){
        for(sb2 in 1:length(symbol_base)){
          symbol=c(symbol,paste(symbol_base[sb1],symbol_base[sb2],sep=""))
        }
      }
      symbol=unique(symbol)
      real_symb=vector()
      if(length(symbol)==0){
        criteria=F
      }
      if(length(symbol)>0){
        nb_symbol=length(symbol)
        pos_s=vector()
        test=list()
        x=vector()
        for(k in 1:nb_symbol){
          test[[k]]=gregexpr(symbol[k],paste(as.character(Os),collapse = ""))
          x[k]=length(test[[k]][[1]])
        }
        if(any(x>1)){
          pos_k=min(which(x==max(x)))
          rep_symbol=symbol[pos_k]
          pos_s=as.vector(as.matrix(test[[pos_k]][[1]]))
         mat_symbol=rbind(mat_symbol,c(new_symbol,rep_symbol))
        Os[pos_s]=new_symbol
        pos_s=pos_s+1
        Os=Os[-pos_s]
        symbol_base=c(symbol_base,as.character(new_symbol))
        rm(test)
        }
        if(count>=max_count)
        {
          criteria=F
        }
      }
    }
  }
  Os=c(ini,Os)
  output[[1]]=Os
  output[[2]]=mat_symbol
  return(output)
}

