#' Build a signal for eSMC
#'
#' Takes a SNP matrix and build a sequence of 0 (two sequences are the same) and 1 (two sequences are difference)
#' @param DNA a segregating sites matrix of three lines. Nucleotides of individuals are on line 1 and 2 and their position on line 3
#' @param n length of the DNA sequence
#' @return The vector of 0 and 1
seqSNP2_MH<-function(DNA,n){
  DNA=as.matrix(DNA)
  pos=which(DNA[1,]!=DNA[2,])
  seq=rep(0,n)
  seq[as.numeric(DNA[3,pos])]=1
  return(seq)
}
