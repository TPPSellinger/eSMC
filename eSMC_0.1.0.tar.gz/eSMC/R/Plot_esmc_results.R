#' Plots results from eSMC
#'
#' @param results : results output from eSMC (separate results if check was TRUE)
#' @param mu : molecular mutation rate
#' @param WP : TRUE to write pdf
#' @param path : location to print pdf
#' @param NC : Number of chromosome or scaffold (must be equal of the size of the list is O is a list of Segregating site matrix)#' @param BoxB : boundaries of the germination rate ( first value must be  bigger than 0)
#' @param x : generations ago bondaries
#' @param y : logarithmic boundaries in base 10 of the population size
#' @param title : title of the plot
#' @param x_sim : time in generation of the simulated data
#' @param y_sim : population size of the simulated data
#' @export
#' @return A pdf or display plot in R
Plot_esmc_results<-function(results,mu,WP=T,path=NA,NC=1,x=c(1,10^7),y=c(2,8),title="Demographic history",x_sim=NA,y_sim=NA){
  sim=F
  if(!is.na(x_sim)&!is.na(y_sim)){
    if(length(x_sim)==length(y_sim)){
      sim=T
    }
  }
    if(is.na(path)){
    path="plot_esmc.pdf"
  }
  if(NC==1){
    if(WP){
      grDevices::pdf(path)
      graphics::plot(x,c(1,1), log=c("x"), ylim =y ,type="n", xlab= paste("Generations ago",sep=" "), ylab="population size (log10)")
      Pop_=results$mu/mu
      graphics::lines((results$Tc*Pop_), log10((as.numeric(results$Xi))*Pop_), type="s", col="red")
     if(sim){graphics::lines(x_sim,y_sim, type="s", col="black")}
      title(title,adj = 0)
      grDevices::dev.off()
    }
    if(!WP){
      graphics::plot(x,c(1,1), log=c("x"), ylim =y ,type="n", xlab= paste("Generations ago",sep=" "), ylab="population size (log10)")
      Pop_=results$mu/mu
      graphics::lines((results$Tc*Pop_), log10((as.numeric(results$Xi))*Pop_), type="s", col="red")
      title(title,adj = 0)
      if(sim){graphics::lines(x_sim,y_sim, type="s", col="black")}
    }
  }
  if(NC>1){
    if(WP){
      grDevices::pdf(path)
      graphics::plot(x,c(1,1), log=c("x"), ylim =y ,type="n", xlab= paste("Generations ago",sep=" "), ylab="population size (log10)")
      for(i in 1:NC){
        Pop_=results[[i]]$mu/mu
        graphics::lines((results[[i]]$Tc*Pop_), log10((as.numeric(results[[i]]$Xi))*Pop_), type="s", col="red")
      }
      title(title,adj = 0)
      if(sim){graphics::lines(x_sim,y_sim, type="s", col="black")}
      grDevices::dev.off()
    }
    if(!WP){
      graphics::plot(x,c(1,1), log=c("x"), ylim =y ,type="n", xlab= paste("Generations ago",sep=" "), ylab="population size (log10)")
      for(i in 1:NC){
        Pop_=results[[i]]$mu/mu
        graphics::lines((results[[i]]$Tc*Pop_), log10((as.numeric(results[[i]]$Xi))*Pop_), type="s", col="red")
      }
      if(sim){graphics::lines(x_sim,y_sim, type="s", col="black")}
      title(title,adj = 0)
    }
  }
}
