#'  Builds the HMM matrices of the new symbol
#'
#' Builds the HMM matrices to analysed the zip signal and calculate likelihood
#' @param A : Transition matrix
#' @param E : emission matrix
#' @param Mat_symbol : Symbol matrix with the zipping pattern
#' @param q : equilibrium probability
#' @return A : 4 object list with matrices to calculate likelihood of zipped sequences
Build_zip_Matrix_mailund<-function(A,E,Mat_symbol,q){
  C=list()
  TO=list()
  l=vector(length =(2+(dim(Mat_symbol)[1])))
  Q=list()
  Q_=list()
  k=length(q)

  for(i in 1:dim(E)[2]){
    B=diag(x=E[,i])
    C[[i]]=B%*%A
    l[i]=1
    TO[[i]]=t(A)%*%B
    Q[[i]]=diag(1,k,k)
    Q_[[i]]=diag(1,k,k)
  }
  x=length(C)
  mat_trick=eigen(TO[[1]])
  D=diag(mat_trick$values)
  for(i in 1:dim(Mat_symbol)[1]){
    sx=strsplit(Mat_symbol[i,2]," ")
    sx=as.numeric(as.matrix(sx[[1]]))
    a=sx[1]
    b=sx[2]
    C[[(x+i)]]=as.matrix(C[[(b+1)]])%*%as.matrix(C[[(a+1)]])
    l[(i+2)]=(l[(a+1)]+l[(b+1)])
    l_temp=(l[(a+1)]+l[(b+1)])
    TO[[x+i]]=TO[[(a+1)]]%*%TO[[(b+1)]]
    Q_temp=matrix(0,dim(D)[1],dim(D)[1])
    Q_temp_=matrix(0,dim(D)[1],dim(D)[1])
    for(x1 in 1:dim(D)[1]){
      for(x2 in 1:dim(D)[1]){
        if(D[x1,x1]!=D[x2,x2]){
          Q_temp[x1,x2]=((D[x1,x1]^(l_temp))-(D[x2,x2]^(l_temp)))/(D[x1,x1]-D[x2,x2] )
          Q_temp_[x1,x2]=sum((D[x1,x1]^seq(1,l_temp,1))*(D[x2,x2]^(l_temp-seq(1,l_temp,1))))
        }
        if(D[x1,x1]==D[x2,x2]){
          Q_temp[x1,x2]=(l_temp)*(D[x2,x2]^(l_temp-1))
          Q_temp_[x1,x2]=(l_temp)*(D[x2,x2]^(l_temp))
        }
      }
    }
    Q[[i+2]]=Q_temp
    Q_[[i+2]]=Q_temp_
  }
  output=list()
  output[[1]]=C
  output[[2]]=Q_
  output[[3]]=TO
  output[[4]]=Q

  return(output)
}
