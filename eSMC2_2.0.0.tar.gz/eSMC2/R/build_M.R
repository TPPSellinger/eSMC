#' Build emission matrix from sequence of genealogy
#'
#' @param Mutation : Segregating matrix 
#' @param genealogy : matrix containing sequence of genealogy
#' @param Tc : Discretisation of time
#' @return matrix of 2 column and size of Tc line corresponding the estimated emission matrix
build_M<-function(Mutation,genealogy,Tc){
  Output=matrix(0,ncol=2,nrow=length(Tc))
  L=0
  for(i in 2:dim(genealogy)[2]){
    pos1=1+genealogy[4,(i-1)]+L
    L=L+genealogy[4,i]
    state=max(which(Tc<genealogy[3,i]))
    Output[state,1]=Output[state,1]+genealogy[4,i]
    genealogy[4,i]=pos1
  }
  state=max(which(Tc<genealogy[3,1]))
  q=rep(0,length(Tc))
  q[state]=1

  Output[state,1]=Output[state,1]+genealogy[4,1]
  genealogy[4,1]=1
  for(i in 1:dim(Mutation)[2]){
    pos=Mutation[3,i]
    state=max(which(Tc<genealogy[3,max(which(genealogy[4,]<pos))]))
    Output[state,1]=Output[state,1]-1
    Output[state,2]=Output[state,2]+1
  }
  res=list()
  res$M=Output
  res$q=q
  return(res)
}
