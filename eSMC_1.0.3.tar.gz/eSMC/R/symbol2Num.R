#'  Builds a numerical zip signal from the zip signal
#'
#' Transform the character sequence into a numeric vector
#' @param Os : original signal (sequence of 0 and 1)
#' @param Mat_symbol : Symbol matrix with the zipping pattern
#' @return A list with first object the ziped numerical sequence, as second the symbol matrix and as third the bp length of each symbol#
symbol2Num<-function(Os,Mat_symbol){
  for(i in 1:dim(Mat_symbol)[1]){
    sym=strsplit(Mat_symbol[i,2],"")
    sym=sym[[1]]
    sym=paste(sym,collapse=" ")
    Mat_symbol[i,2]=sym
  }

  for( i in letters){
    if(any(Mat_symbol[,1]%in%i)){
      pos=which(Os%in%i)
      x=as.numeric(which(letters%in%i))
      Os[pos]=(9+x)
      Mat_symbol[(8+x),1]=9+x
      sym=strsplit(Mat_symbol[(8+x),2]," ")
      sym=sym[[1]]
      if(sym[1]%in%letters){
        sym[1]=9+as.numeric(which(letters%in%sym[1]))
      }
      if(sym[2]%in%letters){
        sym[2]=9+as.numeric(which(letters%in%sym[2]))
      }
      sym=paste(sym,collapse=" ")
      Mat_symbol[(8+x),2]=sym
    }
  }
  output=list()
  output[[1]]=Os
  output[[2]]=Mat_symbol
  mat_length=c("0","1",Mat_symbol[,1])
  mat_length=cbind(mat_length,rep(0,length(mat_length)))
  l=c(1,1)
  for(i in 1:dim(Mat_symbol)[1]){
    sx=strsplit(Mat_symbol[i,2]," ")
    sx=as.numeric(as.matrix(sx[[1]]))
    a=sx[1]
    b=sx[2]
    new_l=l[a+1]+l[b+1]
    l=c(l,new_l)
  }
  mat_length[,2]=l
  output[[3]]=mat_length
  return(output)
}
