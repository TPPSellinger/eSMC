#' Runs the baum-welch algorithm
#'
#' Runs the baum-welch algorithm to estimate demographic history, germination , self-fertilization  and recombinationn rate
#' @param Os : list containing the signal of all analysis
#' @param maxIt : number of expectation and maximization iteration
#' @param L : Sequence length
#' @param mu : estimated mutation rate given prior
#' @param theta_W : average theta waterson per chromosome
#' @param Rho : vector of estimated recombination rate per sequence
#' @param beta : germination rate
#' @param Popfix : True if population size is assumed constant
#' @param SB : True to estimate germination rate
#' @param k : number of hidden states
#' @param BoxB : vector of  size two which are bounderies of germination rate
#' @param BoxP : vector of  size two which to bond  population size variation. First value gives the -log10 of lower bondery and second value the log10 of upper bondery
#' @param Boxr :  vector of  size two which to bond recombination rate. First value gives the -log10 of lower bondery and second value the log10 of upper bondery
#' @param maxBit :  number of run of the  baum-welch algorithm (each time using as prior result from precedent run)
#' @param pop_vect :  vector of hidden states sharing population size parameter (sum must be equal to k).
#' @param window_scaling : vector containing as first value a numeric value to rescale hidden states and as second a numeric value to shift the time windows of hidden states
#' @param sigma : self-fertilization rate
#' @param SF : True to estimate Self-fertilization rate
#' @param Boxs : vector of  size two which are bounderies of self-fertilization rate
#' @param ER : True to estimation recombination rate
#' @param BW : True to run complete baum-welch implementation
#' @param NC : Number of different chromosome or scaffold analyzed
#' @param redo_R : True to reestimation recombination rate if no convergence reached
#' @param Share_r : True is all scaffold share same recombination and mutation rate
#' @return List containing of all model parameters.
Baum_Welch_algo<-function(Os, maxIt =20,L,mu,theta_W,Rho,beta=1,Popfix=T,SB=F,k=20,BoxB=c(0.1,1),BoxP=c(3,3),Boxr=c(1,1),maxBit=1,pop_vect=NA,window_scaling=c(1,0),sigma=0.00,SF=F,Boxs=c(0,0.97),ER=F,BW=F,NC=1,redo_R=F,Share_r=T){
  Xi=NA
  print(paste("sequence length :",L,sep=" "))
  if(length(Rho)>1&length(Rho)!=NC){
    stop("Problem in recombination definition")
  }
  old_list=list()
  Pop=Popfix

  theta=mu*2*L
  gamma=Rho/theta
  if(Share_r){
    mu=mean(mu)
    print("new mu")
    print(mu)
    theta=mu*2*L
    Rho=theta*gamma
    print("new Rho")
    print(Rho)
  }


  gamma_o=gamma
  print(gamma)
  test.env <- new.env()
  test.env$L <- L
  test.env$k <- k
  test.env$mu <- mu
  test.env$Rho <- Rho
  test.env$window_scaling <- window_scaling
  test.env$BW<-BW
  test.env$Pop<-Popfix
  test.env$NC<-NC
  test.env$Share_r<-Share_r
  mb=0
  if(SB){
    BoxB[1]=max(sqrt(0.01),sqrt(BoxB[1]))
    BoxB[2]=min(sqrt(1),sqrt(BoxB[2]))
    beta=max((BoxB[1]^2),beta)
    beta=min(beta,(BoxB[2]^2))
    Beta=beta
  }
  if(SF){
    sigma=min(Boxs[2],sigma)
    sigma=max(sigma,Boxs[1])
    Self=sigma
  }
  if(any(!is.na(pop_vect))){
    Klink=length(pop_vect)
  }
  if((all(is.na(pop_vect))|sum(pop_vect)!=k)){
    Klink=0.5*k
    pop_vect=rep(2, Klink)
    print("Default pop vector")
  }

  test.env$pop_vect <- pop_vect
  if(!SB&!SF){
    maxBit=1
  }
  if(!SB){
    Beta=beta
    test.env$beta <- beta
  }
  if(!SF){
    Self=sigma
    oldSelf=Self
    test.env$sigma <- sigma
  }
  if(!ER){
    Boxr=c(0,0)
  }

  while(mb<maxBit){
    print(paste("Beta:",Beta))
    print(paste("Self:",Self))
    test.env$Beta <- Beta
    test.env$Self <- Self
    test.env$BoxB <- BoxB
    test.env$Boxs <- Boxs
    mb=mb+1
    it <- 0
    if(mb==1){
      if(SB){
        oldbeta=(sqrt(beta)-BoxB[1])/(BoxB[2]-BoxB[1])
      }
      if(SF){
        oldsigma=(sigma-Boxs[1])/(Boxs[2]-Boxs[1])
      }

    }
    if(mb>1){
      if(SB){
        beta=((oldbeta*(BoxB[2]-BoxB[1]))+BoxB[1])^2
      }
      if(SF){
        sigma=oldsigma*(Boxs[2]-Boxs[1])
        sigma=sigma+Boxs[1]
      }
      if(!Popfix){
        xx=0
        for(ix in 1:Klink){
          x=xx+1
          xx = xx + pop_vect[ix]
          oldXi[x:xx]=oldXi_[ix]
        }
        Xi_=oldXi*sum(BoxP)
        Xi_=Xi_-(BoxP[1])
        Xi_=10^Xi_
      }

      if(NC==1){
        theta=(((theta_W*(beta^2)))*2/(2-sigma))
        mu=theta/(2*L)
        Rho=gamma*theta
      }
      if(NC>1){
        theta=mean(theta_W/(2*L))
        if(Share_r){
          mu=mean(((theta*(beta^2)))*2/(2-sigma))
        }else{
          mu=((theta*(beta^2)))*2/(2-sigma)
        }

        Rho=gamma*theta*2*L
      }

      test.env$mu <- mu
      test.env$Rho <- Rho
    }
    if(!ER){
      if(NC==1|Share_r){
      oldrho=0
      }else{
        oldrho=rep(0,NC)
      }

    }
    if(ER){
      if(NC==1|Share_r){
        oldrho=(Boxr[1]/sum(Boxr))
      }else{
        oldrho=rep((Boxr[1]/sum(Boxr)),NC)
      }
    }
    oldXi_=rep((BoxP[1]/sum(BoxP)),Klink)
    oldXi=vector()
    xx=0
    for(ix in 1:Klink){
      x=xx+1
      xx = xx + pop_vect[ix]
      oldXi[x:xx]=oldXi_[ix]
    }
    Do_BW=T
    restart=F
    test.env$Boxs <- Boxs
    while (it<maxIt&!restart){
      start_time <- Sys.time()
      restart=F
      if(!Do_BW){
        it=0
        oldXi_=rep((BoxP[1]/sum(BoxP)),Klink)
        oldXi=vector()
        xx=0
        for(ix in 1:Klink){
          x=xx+1
          xx = xx + pop_vect[ix]
          oldXi[x:xx]=oldXi_[ix]
        }
      }
      it <- it+1;
      print(paste("It:",it))
      if(Popfix){
        rho_=oldrho*sum(Boxr)
        rho_=rho_-(Boxr[1])
        rho_=10^(rho_)
        rho_=rho_*Rho
        if(SB){
          beta=((oldbeta*(BoxB[2]-BoxB[1]))+BoxB[1])^2
        }
        if(SF){
          sigma=oldsigma*(Boxs[2]-Boxs[1])
          sigma=sigma+Boxs[1]
        }
        print(c("sigma:",sigma,"beta :",beta))
        if(Share_r){
          print(c("rho/theta:",mean(rho_/theta)))
        }else{
          print(c("rho/theta:",rho_/theta))
        }
        Keep_going=F
        if(it==1){
          diff_o=0
        }
        if(it>1){
          diff_o=max(abs(sigma_o-sigma),abs(beta_o-beta))
          count_diff_o=0
          if(diff_o>=0.003){
            if(it==maxIt){
              count_diff_o=count_diff_o+1
              maxIt=maxIt+1
              if(count_diff_o>10){
                maxBit=maxBit-1
              }
            }
          }
        }
        sigma_o=sigma
        beta_o=beta
        if(NC==1){
          builder=build_HMM_matrix(k,(rho_),beta,L=L,Pop=Pop,Xi=NA,Beta,scale=window_scaling,sigma =sigma,Sigma = Self)
        }
        if(NC>1){
          if(Share_r){
            builder=build_HMM_matrix(k,(rho_[1]),beta,L=L[1],Pop=Pop,Xi=NA,Beta,scale=window_scaling,sigma =sigma,Sigma = Self)
          }else{
            builder=list()
            for(chr in 1:NC){
              builder[[chr]]=build_HMM_matrix(k,(rho_[chr]),beta,L=L[chr],Pop=Pop,Xi=NA,Beta,scale=window_scaling,sigma =sigma,Sigma = Self)
            }
          }
        }
      }
      if(!Popfix){
        xx=0
        for(ix in 1:Klink){
          x=xx+1
          xx = xx + pop_vect[ix]
          oldXi[x:xx]=oldXi_[ix]
        }
        Xi_=oldXi*sum(BoxP)
        Xi_=Xi_-(BoxP[1])
        Xi_=10^Xi_
        rho_=oldrho*sum(Boxr)
        rho_=rho_-(Boxr[1])
        rho_=10^(rho_)
        rho_=rho_*Rho
        if(SB){

          beta=((oldbeta*(BoxB[2]-BoxB[1]))+BoxB[1])^2
        }
        if(SF){
          sigma=oldsigma*(Boxs[2]-Boxs[1])
          sigma=sigma+Boxs[1]
        }
        if(Share_r){
          print(c("rho/theta:",mean(rho_/theta)))
        }else{
          print(c("rho/theta:",rho_/theta))
        }
        Keep_going=F
        if(it==1){
          diff_o=0
        }
        if(it>1){
          diff_o=max(abs(sigma_o-sigma),abs(beta_o-beta))
          count_diff_o=0
          if(diff_o>=0.003){
            if(it==maxIt){
              count_diff_o=count_diff_o+1
              maxIt=maxIt+1
              if(count_diff_o>10){
                maxBit=maxBit-1
              }
            }
          }
        }
        sigma_o=sigma
        beta_o=beta

        if(NC==1){
          builder=build_HMM_matrix(k,(rho_),beta,L=L,Pop=Pop,Xi_,Beta,scale=window_scaling,sigma =sigma,Sigma = Self)
        }
        if(NC>1){
          if(Share_r){
            builder=build_HMM_matrix(k,(rho_[1]),beta,L=L[1],Pop=Pop,Xi=Xi_,Beta,scale=window_scaling,sigma =sigma,Sigma = Self)
          }else{
            builder=list()
            for(chr in 1:NC){
              builder[[chr]]=build_HMM_matrix(k,(rho_[chr]),beta,L=L[chr],Pop=Pop,Xi_,Beta,scale=window_scaling,sigma =sigma,Sigma = Self)
            }
          }
        }
      }
      if(NC==1){
        Q = builder[[1]]
        nu= builder[[2]]
        Tc=builder[[3]]
        g=matrix(0,nrow=length(Tc),ncol=3)
        g[,2]=1-exp(-mu*2*Tc)
        g[,1]=exp(-mu*2*Tc)
        g[,3]=1
        M=matrix(0,nrow=length(Tc),ncol=3)
        N=matrix(0,length(Tc),length(Tc))
        MLH=0
        q_=rep(0,length(Tc))
        s_t=Sys.time()
        test=Build_zip_Matrix_mailund(Q,g,Os[[1]][[2]],nu)
        e_t=Sys.time()
        print(e_t-s_t)

        for(i in 1:length(Os)){
          fo=forward_zip_mailund(Os[[i]][[1]],g,nu,test[[1]])
          MLH=MLH+fo[[3]]
          c=exp(fo[[2]])
          ba=Backward_zip_mailund(Os[[i]][[1]],test[[3]],length(Tc),c)

          W_P=list()
          W_P_=list()
          count_oo=0
          for(oo in c(1,3)){
            count_oo=count_oo+1
            int=t(Q)%*%diag(g[,oo])
            int=eigen(int)
            W_P[[count_oo]]=int$vectors
            W_P_[[count_oo]]=solve(W_P[[count_oo]])
          }
          symbol= c(0:2,10:40)
          for(ob in 1){
            truc_M=matrix(0,nrow=length(Tc),ncol=3)
            if(as.numeric(Os[[i]][[1]][(ob+1)])<=2){
              truc_N=(fo[[1]][,ob]%*%(t(ba[,(ob+1)]*g[,(as.numeric(Os[[i]][[1]][(ob+1)])+1)]/c[(ob+1)])))
              truc_M[,(as.numeric(Os[[i]][[1]][(ob+1)])+1)]=fo[[1]][,ob]*(test[[2]][[(as.numeric(Os[[i]][[1]][(ob+1)])+1)]]%*%(ba[,(ob+1)]/c[(ob+1)]))
            }else{

              if(as.numeric(Os[[i]][[1]][(ob+1)])<30){
                truc_N=(t(W_P_[[1]])%*%(t(W_P[[1]])%*%fo[[1]][,ob]%*%t(ba[,(ob+1)]/c[(ob+1)])%*%t(W_P_[[1]])*test[[4]][[(as.numeric(Os[[i]][[1]][(ob+1)]))]])%*%(t(W_P[[1]]))%*%diag(g[,1]))
                truc_M[,1]=diag(t(W_P_[[1]])%*%(t(W_P[[1]])%*%fo[[1]][,ob]%*%t(ba[,(ob+1)]/c[(ob+1)])%*%t(W_P_[[1]]))*test[[2]][[(as.numeric(Os[[i]][[1]][(ob+1)]))]]%*%t(W_P[[1]]))
              }else{
                truc_N=(t(W_P_[[2]])%*%(t(W_P[[2]])%*%fo[[1]][,ob]%*%t(ba[,(ob+1)]/c[(ob+1)])%*%t(W_P_[[2]])*test[[4]][[(as.numeric(Os[[i]][[1]][(ob+1)]))]])%*%(t(W_P[[2]]))%*%diag(g[,3]))
                truc_M[,3]=diag(t(W_P_[[2]])%*%(t(W_P[[2]])%*%fo[[1]][,ob]%*%t(ba[,(ob+1)]/c[(ob+1)])%*%t(W_P_[[2]]))*test[[2]][[(as.numeric(Os[[i]][[1]][(ob+1)]))]]%*%t(W_P[[2]]))

              }
            }
          }
          #truc_N=sum_chi_corrected(fo[[1]][,ob],ba[,(ob+1)],test[[4]],Os[[i]][[1]][(ob+1)],g,W,c[(ob+1)])
          N=N+truc_N
          #truc_M=sum_M_cor(fo[[1]][,ob],ba[,(ob+1)],Os[[i]][[1]][(ob+1)],test[[2]],W,(c[(ob+1)]),test[[1]])
          M=M+truc_M

          for(sym in sort(symbol)){
            ob=as.numeric(sym)
            pos=which(as.numeric(Os[[i]][[1]][-c(1,length(Os[[i]][[1]]))])==ob)
            if(length(pos)>0){
              pos=pos+1
              #print("expected L:")
              #print(Os[[3]][which(Os[[3]][,1]==sym),2]*length(pos))
              #print("ob:")
              #print(ob)
              if(ob<3){
                # print("expected L:")
                #  print(length(pos))
                ba_t=t(t(ba[,(pos)])/c[(pos)])
                truc=c(rowSums(fo[[1]][,(pos-1)]*(test[[1]][[(ob+1)]]%*%ba_t)))
                truc=(truc/(sum(truc)))*length(pos)
                M[,(ob+1)]=M[,(ob+1)]+ truc
                truc_N=(fo[[1]][,(pos-1)]%*%(t(diag(g[,(ob+1)])%*%ba_t)))
                # print("calculated L:")
                #  print(sum(truc_N*t(Q)))
                N=N+truc_N
              }else{
                if(ob<30){
                  A=(t(W_P[[1]])%*%fo[[1]][,(pos-1)]%*%t(t(t(ba[,(pos)])/c[(pos)]))%*%t(W_P_[[1]]))
                  A_=A*test[[2]][[(ob)]]
                  A_=(t(W_P_[[1]])%*%A_%*%t(W_P[[1]]))
                  M[,1]=M[,1]+(diag(A_))
                  A_=A*test[[4]][[(ob)]]
                  A_=(t(W_P_[[1]])%*%A_%*%t(W_P[[1]]))
                  truc_N=((A_%*%diag(g[,1])))
                }else{
                  A=(t(W_P[[2]])%*%fo[[1]][,(pos-1)]%*%t(t(t(ba[,(pos)])/c[(pos)]))%*%t(W_P_[[2]]))
                  A_=A*test[[2]][[(ob)]]
                  A_=(t(W_P_[[2]])%*%A_%*%t(W_P[[2]]))
                  M[,3]=M[,3]+(diag(A_))
                  A_=A*test[[4]][[(ob)]]
                  A_=(t(W_P_[[2]])%*%A_%*%t(W_P[[2]]))
                  truc_N=((A_%*%diag(g[,3])))
                }

                #print("calculated L:")
                #print(sum(truc_N*t(Q)))
                N=N+truc_N
              }
            }
          }

          if(as.numeric(Os[[i]][[1]][length(Os[[i]][[1]])])<=3){
            M[,(as.numeric(Os[[i]][[1]][length(Os[[i]][[1]])])+1)]=M[,(as.numeric(Os[[i]][[1]][length(Os[[i]][[1]])])+1)]+(fo[[1]][,length(Os[[i]][[1]])]*ba[,length(Os[[i]][[1]])])
          }else{
            if(as.numeric(Os[[i]][[1]][length(Os[[i]][[1]])])<30){

              M[,1]=M[,1]+((fo[[1]][,length(Os[[i]][[1]])]*ba[,length(Os[[i]][[1]])])/sum(fo[[1]][,length(Os[[i]][[1]])]*ba[,length(Os[[i]][[1]])]))
            }else{
              M[,3]=M[,3]+((fo[[1]][,length(Os[[i]][[1]])]*ba[,length(Os[[i]][[1]])])/sum(fo[[1]][,length(Os[[i]][[1]])]*ba[,length(Os[[i]][[1]])]))

            }
          }
          q_=q_+((fo[[1]][,1]*ba[,1])/sum(fo[[1]][,1]*ba[,1]))
        }
        N=N*t(Q)

        Scale_N=(L-1)/sum(N)
        N=N*Scale_N
        Scale_M=L/sum(M)
        M=M*Scale_M
        q_=q_/sum(q_)
      }

      if(NC>1){
        if(Share_r){
          Q = builder[[1]]
          nu= builder[[2]]
          Tc=builder[[3]]
          g=matrix(0,nrow=length(Tc),ncol=3)
          g[,2]=1-exp(-mu*2*Tc)
          g[,3]=1
          g[,1]=exp(-mu*2*Tc)
          M=matrix(0,nrow=length(Tc),ncol=3)
          N=matrix(0,length(Tc),length(Tc))
          MLH=0
          q_=rep(0,length(Tc))
          s_t=Sys.time()
          test=Build_zip_Matrix_mailund(Q,g,Os[[1]][[1]][[2]],nu)
          e_t=Sys.time()
          print(e_t-s_t)
          for(chr in 1:NC ){
            for(i in 1:length(Os[[chr]])){
              fo=forward_zip_mailund(Os[[chr]][[i]][[1]],g,nu,test[[1]])
              MLH=MLH+fo[[3]]
              c=exp(fo[[2]])
              ba=Backward_zip_mailund(Os[[chr]][[i]][[1]],test[[3]],length(Tc),c)
              W_P=list()
              W_P_=list()
              count_oo=0
              for(oo in c(1,3)){
                count_oo=count_oo+1
                int=t(Q)%*%diag(g[,oo])
                int=eigen(int)
                W_P[[count_oo]]=int$vectors
                W_P_[[count_oo]]=solve(W_P[[count_oo]])
              }
              symbol= c(0:2,10:40)
              for(ob in 1){
                truc_M=matrix(0,nrow=length(Tc),ncol=3)
                if(as.numeric(Os[[chr]][[i]][[1]][(ob+1)])<=4){
                  truc_N=(fo[[1]][,ob]%*%(t(ba[,(ob+1)]*g[,(as.numeric(Os[[chr]][[i]][[1]][(ob+1)])+1)]/c[(ob+1)])))
                  truc_M[,(as.numeric(Os[[chr]][[i]][[1]][(ob+1)])+1)]=fo[[1]][,ob]*(test[[2]][[(as.numeric(Os[[chr]][[i]][[1]][(ob+1)])+1)]]%*%(ba[,(ob+1)]/c[(ob+1)]))
                }else{
                  if(as.numeric(Os[[chr]][[i]][[1]][(ob+1)])<30){
                    truc_N=(t(W_P_[[1]])%*%(t(W_P[[1]])%*%fo[[1]][,ob]%*%t(ba[,(ob+1)]/c[(ob+1)])%*%t(W_P_[[1]])*test[[4]][[(as.numeric(Os[[chr]][[i]][[1]][(ob+1)]))]])%*%(t(W_P[[1]]))%*%diag(g[,1]))
                    truc_M[,1]=diag(t(W_P_[[1]])%*%(t(W_P[[1]])%*%fo[[1]][,ob]%*%t(ba[,(ob+1)]/c[(ob+1)])%*%t(W_P_[[1]]))*test[[2]][[(as.numeric(Os[[chr]][[i]][[1]][(ob+1)]))]]%*%t(W_P[[1]]))

                  }else{
                    truc_N=(t(W_P_[[2]])%*%(t(W_P[[2]])%*%fo[[1]][,ob]%*%t(ba[,(ob+1)]/c[(ob+1)])%*%t(W_P_[[2]])*test[[4]][[(as.numeric(Os[[chr]][[i]][[1]][(ob+1)]))]])%*%(t(W_P[[2]]))%*%diag(g[,3]))
                    truc_M[,3]=diag(t(W_P_[[2]])%*%(t(W_P[[2]])%*%fo[[1]][,ob]%*%t(ba[,(ob+1)]/c[(ob+1)])%*%t(W_P_[[2]]))*test[[2]][[(as.numeric(Os[[chr]][[i]][[1]][(ob+1)]))]]%*%t(W_P[[2]]))

                  }
                }
                N=N+truc_N
                M=M+truc_M
              }
              for(sym in symbol){
                ob=as.numeric(sym)
                pos=which(as.numeric(Os[[chr]][[i]][[1]][-c(1,length(Os[[chr]][[i]][[1]]))])==ob)
                if(length(pos)>0){
                  pos=pos+1
                  if(ob<5){
                    ba_t=t(t(ba[,(pos)])/c[(pos)])
                    truc=c(rowSums(fo[[1]][,(pos-1)]*(test[[1]][[(ob+1)]]%*%ba_t)))
                    truc=(truc/(sum(truc)))*length(pos)
                    M[,(ob+1)]=M[,(ob+1)]+ truc
                    N=N+(fo[[1]][,(pos-1)]%*%(t(diag(g[,(ob+1)])%*%ba_t)))
                  }else{
                    if(ob<30){
                      A=(t(W_P[[1]])%*%fo[[1]][,(pos-1)]%*%t(t(t(ba[,(pos)])/c[(pos)]))%*%t(W_P_[[1]]))
                      A_=A*test[[2]][[(ob)]]
                      A_=(t(W_P_[[1]])%*%A_%*%t(W_P[[1]]))
                      M[,1]=M[,1]+(diag(A_))
                      A_=A*test[[4]][[(ob)]]
                      A_=(t(W_P_[[1]])%*%A_%*%t(W_P[[1]]))
                      N=N+((A_%*%diag(g[,1])))
                    }else{
                      A=(t(W_P[[2]])%*%fo[[1]][,(pos-1)]%*%t(t(t(ba[,(pos)])/c[(pos)]))%*%t(W_P_[[2]]))
                      A_=A*test[[2]][[(ob)]]
                      A_=(t(W_P_[[2]])%*%A_%*%t(W_P[[2]]))
                      M[,3]=M[,3]+(diag(A_))
                      A_=A*test[[4]][[(ob)]]
                      A_=(t(W_P_[[2]])%*%A_%*%t(W_P[[2]]))
                      N=N+((A_%*%diag(g[,3])))
                    }
                  }
                }
              }
              if(as.numeric(Os[[chr]][[i]][[1]][length(Os[[chr]][[i]][[1]])])<=3){
                M[,(as.numeric(Os[[chr]][[i]][[1]][length(Os[[chr]][[i]][[1]])])+1)]=M[,(as.numeric(Os[[chr]][[i]][[1]][length(Os[[chr]][[i]][[1]])])+1)]+(fo[[1]][,length(Os[[chr]][[i]][[1]])]*ba[,length(Os[[chr]][[i]][[1]])])
              }
              if(as.numeric(Os[[chr]][[i]][[1]][length(Os[[chr]][[i]][[1]])])>3){
                if(as.numeric(Os[[chr]][[i]][[1]][length(Os[[chr]][[i]][[1]])])<30){
                  M[,1]=M[,1]+((fo[[1]][,length(Os[[chr]][[i]][[1]])]*ba[,length(Os[[chr]][[i]][[1]])])/sum(fo[[1]][,length(Os[[chr]][[i]][[1]])]*ba[,length(Os[[chr]][[i]][[1]])]))

                }else{
                  M[,3]=M[,3]+((fo[[1]][,length(Os[[chr]][[i]][[1]])]*ba[,length(Os[[chr]][[i]][[1]])])/sum(fo[[1]][,length(Os[[chr]][[i]][[1]])]*ba[,length(Os[[chr]][[i]][[1]])]))

                }
              }
              q_=q_+((fo[[1]][,1]*ba[,(1)])/sum(fo[[1]][,1]*ba[,(1)]))
            }

          }

          N=N*t(Q)
          Scale_N=(sum(L)-length(L))/sum(N)
          N=N*Scale_N
          Scale_M=sum(L)/sum(M)
          M=M*Scale_M
          q_=q_/sum(q_)
        }else{
          Q=list()
          nu=list()
          Tc=list()
          g=list()
          M=list()
          N=list()
          MLH=list()
          q_=list()
          for(chr in 1:NC){
            Q[[chr]] = builder[[chr]][[1]]
            nu[[chr]]= builder[[chr]][[2]]
            Tc[[chr]]=builder[[chr]][[3]]
            g[[chr]]=matrix(0,nrow=length(Tc[[chr]]),ncol=3)
            g[[chr]][,3]=1
            g[[chr]][,2]=1-exp(-mu[chr]*2*Tc[[chr]])
            g[[chr]][,1]=exp(-mu[chr]*2*Tc[[chr]])
            M[[chr]]=matrix(0,nrow=length(Tc[[chr]]),ncol=3)
            N[[chr]]=matrix(0,length(Tc[[chr]]),length(Tc[[chr]]))
            MLH[[chr]]=0
            q_[[chr]]=rep(0,length(Tc[[chr]]))
            test=Build_zip_Matrix_mailund(Q[[chr]],g[[chr]],Os[[chr]][[1]][[2]],nu[[chr]])

            for(i in 1:length(Os[[chr]])){
              fo=forward_zip_mailund(Os[[chr]][[i]][[1]],g[[chr]],nu[[chr]],test[[1]])
              MLH[[chr]]=MLH[[chr]]+fo[[3]]
              c=exp(fo[[2]])
              ba=Backward_zip_mailund(Os[[chr]][[i]][[1]],test[[3]],length(Tc[[chr]]),c)
              W_P=list()
              W_P_=list()
              count_oo=0
              for(oo in c(1,3)){
                count_oo=count_oo+1
                int=t(Q[[chr]])%*%diag(g[[chr]][,oo])
                int=eigen(int)
                W_P[[count_oo]]=int$vectors
                W_P_[[count_oo]]=solve(W_P[[count_oo]])
              }
              symbol= c(0:2,10:40)
              for(ob in 1){
                truc_M=matrix(0,nrow=length(Tc[[chr]]),ncol=3)
                if(as.numeric(Os[[chr]][[i]][[1]][(ob+1)])<=4){
                  truc_N=(fo[[1]][,ob]%*%(t(ba[,(ob+1)]*g[[chr]][,(as.numeric(Os[[chr]][[i]][[1]][(ob+1)])+1)]/c[(ob+1)])))
                  truc_M[,(as.numeric(Os[[chr]][[i]][[1]][(ob+1)])+1)]=fo[[1]][,ob]*(test[[2]][[(as.numeric(Os[[chr]][[i]][[1]][(ob+1)])+1)]]%*%(ba[,(ob+1)]/c[(ob+1)]))
                }else{
                  if(as.numeric(Os[[chr]][[i]][[1]][(ob+1)])<30){
                    truc_N=(t(W_P_[[1]])%*%(t(W_P[[1]])%*%fo[[1]][,ob]%*%t(ba[,(ob+1)]/c[(ob+1)])%*%t(W_P_[[1]])*test[[4]][[(as.numeric(Os[[chr]][[i]][[1]][(ob+1)]))]])%*%(t(W_P[[1]]))%*%diag(g[[chr]][,1]))
                    truc_M[,1]=diag(t(W_P_[[1]])%*%(t(W_P[[1]])%*%fo[[1]][,ob]%*%t(ba[,(ob+1)]/c[(ob+1)])%*%t(W_P_[[1]]))*test[[2]][[(as.numeric(Os[[chr]][[i]][[1]][(ob+1)]))]]%*%t(W_P[[1]]))
                  }else{
                    truc_N=(t(W_P_[[2]])%*%(t(W_P[[2]])%*%fo[[1]][,ob]%*%t(ba[,(ob+1)]/c[(ob+1)])%*%t(W_P_[[2]])*test[[4]][[(as.numeric(Os[[chr]][[i]][[1]][(ob+1)]))]])%*%(t(W_P[[2]]))%*%diag(g[[chr]][,3]))
                    truc_M[,3]=diag(t(W_P_[[2]])%*%(t(W_P[[2]])%*%fo[[1]][,ob]%*%t(ba[,(ob+1)]/c[(ob+1)])%*%t(W_P_[[2]]))*test[[2]][[(as.numeric(Os[[chr]][[i]][[1]][(ob+1)]))]]%*%t(W_P[[2]]))

                  }

                }
                N[[chr]]=N[[chr]]+truc_N
                M[[chr]]=M[[chr]]+truc_M
              }
              for(sym in symbol){
                ob=as.numeric(sym)
                pos=which(as.numeric(Os[[chr]][[i]][[1]][-c(1,length(Os[[chr]][[i]][[1]]))])==ob)
                if(length(pos)>0){
                  pos=pos+1
                  if(ob<3){
                    ba_t=t(t(ba[,(pos)])/c[(pos)])
                    truc=c(rowSums(fo[[1]][,(pos-1)]*(test[[1]][[(ob+1)]]%*%ba_t)))
                    truc=(truc/(sum(truc)))*length(pos)
                    M[[chr]][,(ob+1)]=M[[chr]][,(ob+1)]+ truc
                    N[[chr]]=N[[chr]]+(fo[[1]][,(pos-1)]%*%(t(diag(g[[chr]][,(ob+1)])%*%ba_t)))
                  }else{
                    if(ob<30){
                      A=(t(W_P[[1]])%*%fo[[1]][,(pos-1)]%*%t(t(t(ba[,(pos)])/c[(pos)]))%*%t(W_P_[[1]]))
                      A_=A*test[[2]][[(ob)]]
                      A_=(t(W_P_[[1]])%*%A_%*%t(W_P[[1]]))
                      M[[chr]][,1]=M[[chr]][,1]+(diag(A_))
                      A_=A*test[[4]][[(ob)]]
                      A_=(t(W_P_[[1]])%*%A_%*%t(W_P[[1]]))
                      N[[chr]]=N[[chr]]+((A_%*%diag(g[[chr]][,1])))
                    }else{
                      A=(t(W_P[[2]])%*%fo[[1]][,(pos-1)]%*%t(t(t(ba[,(pos)])/c[(pos)]))%*%t(W_P_[[2]]))
                      A_=A*test[[2]][[(ob)]]
                      A_=(t(W_P_[[2]])%*%A_%*%t(W_P[[2]]))
                      M[[chr]][,3]=M[[chr]][,3]+(diag(A_))
                      A_=A*test[[4]][[(ob)]]
                      A_=(t(W_P_[[2]])%*%A_%*%t(W_P[[2]]))
                      N[[chr]]=N[[chr]]+((A_%*%diag(g[[chr]][,3])))
                    }
                  }
                }
              }
              if(as.numeric(Os[[chr]][[i]][[1]][length(Os[[chr]][[i]][[1]])])<=3){
                M[[chr]][,(as.numeric(Os[[chr]][[i]][[1]][length(Os[[chr]][[i]][[1]])])+1)]=M[[chr]][,(as.numeric(Os[[chr]][[i]][[1]][length(Os[[chr]][[i]][[1]])])+1)]+(fo[[1]][,length(Os[[chr]][[i]][[1]])]*ba[,length(Os[[chr]][[i]][[1]])])
              }
              if(as.numeric(Os[[chr]][[i]][[1]][length(Os[[chr]][[i]][[1]])])>3){
                if(as.numeric(Os[[chr]][[i]][[1]][length(Os[[chr]][[i]][[1]])])<30){
                  M[[chr]][,1]=M[[chr]][,1]+((fo[[1]][,length(Os[[chr]][[i]][[1]])]*ba[,length(Os[[chr]][[i]][[1]])])/sum(fo[[1]][,length(Os[[chr]][[i]][[1]])]*ba[,length(Os[[chr]][[i]][[1]])]))

                }else{
                  M[[chr]][,3]=M[[chr]][,3]+((fo[[1]][,length(Os[[chr]][[i]][[1]])]*ba[,length(Os[[chr]][[i]][[1]])])/sum(fo[[1]][,length(Os[[chr]][[i]][[1]])]*ba[,length(Os[[chr]][[i]][[1]])]))

                }
              }
              q_[[chr]]=q_[[chr]]+((fo[[1]][,1]*ba[,(1)])/sum(fo[[1]][,1]*ba[,(1)]))
            }

            N[[chr]]=N[[chr]]*t(Q[[chr]])
            Scale_N=(L[chr]-1)/sum(N[[chr]])
            N[[chr]]=N[[chr]]*Scale_N
            Scale_M=L[chr]/sum(M[[chr]])
            M[[chr]]=M[[chr]]*Scale_M
            q_[[chr]]=q_[[chr]]/sum(q_[[chr]])
          }
        }
      }
      if(it>1){
        print(paste(" old Likelihood: ",oldMLH))
      }
      if(NC==1){
        print(paste(" New Likelihood: ",MLH))

        if(it>1){

          if(oldMLH > MLH|MLH=="NaN"){

            if(it>2){
              restart=T
              if(!Popfix){
                oldXi_=oldXi_s
              }
              if(ER){
                oldrho=oldrho_s
              }
              if(SB){
                oldbeta=oldbeta_s
              }
              if(SF){
                oldsigma=oldsigma_s
              }
            }
            if(it==2){
              print("Algortihm has converge but may need more data for better results ")
              restart=T
              MB=maxBit
            }
          }

        }
        oldMLH=MLH
      }
      if(NC>1){
        if(Share_r){
          print(paste("New Likelihood: ",MLH))
          if(it>1){
            if(oldMLH > MLH|MLH=="NaN"){
              if(it>1){
                restart=T
                if(!Popfix){
                  oldXi_=oldXi_s
                }
                if(ER){
                  oldrho=oldrho_s
                }
                if(SB){
                  oldbeta=oldbeta_s
                }
                if(SF){
                  oldsigma=oldsigma_s
                }
              }
              if(it==2){
                print("Algortihm has converge but may need more data for better results ")
                restart=T
                MB=maxBit
              }
            }

          }
          oldMLH=MLH
        }else{
        MLH1=0
        for(chr in 1:length(MLH)){
          MLH1=MLH[[chr]]+MLH1
        }
        print(paste("New Likelihood: ",MLH1))
        if(it>1){
          if(oldMLH > MLH1|MLH1=="NaN"){
            if(it>1){
              restart=T
              if(!Popfix){
                oldXi_=oldXi_s
              }
              if(ER){
                oldrho=oldrho_s
              }
              if(SB){
                oldbeta=oldbeta_s
              }
              if(SF){
                oldsigma=oldsigma_s
              }
            }
            if(it==2){
              print("Algortihm has converge but may need more data for better results ")
              restart=T
              MB=maxBit
            }
          }

        }
        oldMLH=MLH1
        }
      }
      if(!restart){

        if(NC==1){
          x=as.vector(g)
          keep=which(x>0)
          x=x[keep]
          m=as.vector(M)
          m=m[keep]
          A=as.vector(t(Q))
          keep=which(A>0)
          A=A[keep]
          Big_Xi=as.vector(N)
          Big_Xi=Big_Xi[keep]
          if(BW){
            LH=Re(sum(log(A)*Big_Xi)+sum(log(x)*m)+sum(log(nu)*q_))
          }
          if(!BW){
            LH=Re(sum(log(A)*Big_Xi))
          }
          oldLH=-LH
          test.env$Big_Xi <- N
          test.env$Big_M <-M
          test.env$q_ <-q_
        }
        if(NC>1){
          test.env$Big_Xi <- N
          test.env$Big_M <-M
          test.env$q_ <-q_
        }
        Do_BW=T
        if(!Popfix){
          oldXi_s=oldXi_
        }
        if(ER){
          oldrho_s=oldrho
        }
        if(SB){
          oldbeta_s=oldbeta
        }
        if(SF){
          oldsigma_s=oldsigma
        }
        lr=length(oldrho)
        test.env$lr<-lr
        if(Do_BW){
          if(NC==1){
            if(ER){
              if(SB){
                if(SF){
                  if(Popfix){
                    function_to_minimize <-function(param){
                      Boxr=get('Boxr', envir=test.env)
                      mu=get('mu', envir=test.env)
                      rho_=param[1]
                      rho_=rho_*sum(Boxr)
                      rho_=rho_-(Boxr[1])
                      rho_=10^(rho_)
                      Rho=get('Rho', envir=test.env)
                      rho_=rho_*Rho
                      BoxB=get('BoxB', envir=test.env)
                      beta=((param[2]*(BoxB[2]-BoxB[1]))+BoxB[1])^2
                      L=get('L', envir=test.env)
                      n=get('k', envir=test.env)
                      Big_Xi=get('Big_Xi', envir=test.env)
                      Big_M=get('Big_M', envir=test.env)
                      Beta=get('Beta', envir=test.env)
                      Boxs=get('Boxs', envir=test.env)
                      Self=get('Self', envir=test.env)
                      sigma=param[3]
                      sigma=sigma*(Boxs[2]-Boxs[1])
                      sigma=sigma+Boxs[1]
                      sigma=min(sigma,0.99)
                      window_scaling=get('window_scaling', envir=test.env)
                      BW=get('BW', envir=test.env)

                      Pop=get('Pop', envir=test.env)

                      builder=build_HMM_matrix(n,rho_,beta,Pop = Pop,L=L,Beta=Beta,scale=window_scaling,sigma = sigma,Sigma = Self) #
                      Q=builder[[1]]
                      Q=t(Q)
                      A=as.vector(Q)
                      keep=which(A>0)
                      A=A[keep]
                      Big_Xi=as.vector(Big_Xi)
                      Big_Xi=Big_Xi[keep]
                      Tc=builder[[3]]
                      g=matrix(0,nrow=length(Tc),ncol=3)
                      g[,3]=1
                      g[,2]=1-exp(-mu*2*Tc)
                      g[,1]=exp(-mu*2*Tc)
                      x=as.vector(g)
                      keep=which(x>0)
                      x=x[keep]
                      m=as.vector(Big_M)
                      m=m[keep]
                      q_=get('q_', envir=test.env)
                      nu=builder[[2]]
                      if(BW){
                        LH=-sum(log(A)*Big_Xi)-sum(log(x)*m)-sum(log(nu)*q_)
                      }
                      if(!BW){
                        LH=-sum(log(A)*Big_Xi)
                      }
                      return(LH)
                    }
                    sol= BB::BBoptim(c(oldrho,oldbeta,oldsigma),function_to_minimize,lower=0,upper=1,method=c(2),control = list(maxit=15+length(c(oldrho,oldbeta,oldsigma)),M=c(20)))
                    LH=as.numeric(as.matrix(sol[[2]]))
                    sol=as.matrix(sol[[1]])
                    sol=as.numeric(sol[1:3,1])
                    rho=sol[1]
                    beta_=sol[2]
                    sigma_=sol[3]
                    if(LH<oldLH){
                      oldrho=rho
                      oldbeta=beta_
                      oldsigma=sigma_
                    }
                  }
                  if(!Popfix){
                    function_to_minimize<-function(param){
                      Boxr=get('Boxr', envir=test.env)
                      mu=get('mu', envir=test.env)
                      rho_=param[1]
                      rho_=rho_*sum(Boxr)
                      rho_=rho_-(Boxr[1])
                      rho_=10^(rho_)
                      Rho=get('Rho', envir=test.env)
                      rho_=rho_*Rho
                      BoxB=get('BoxB', envir=test.env)
                      Boxs=get('Boxs', envir=test.env)
                      beta=((param[2]*(BoxB[2]-BoxB[1]))+BoxB[1])^2
                      BoxP=get('BoxP', envir=test.env)
                      sigma=param[3]
                      sigma=sigma*(Boxs[2]-Boxs[1])
                      sigma=sigma+Boxs[1]
                      sigma=min(sigma,0.99)
                      Xi_=param[4:length(param)]
                      Xi=vector()
                      pop_vect=get('pop_vect', envir=test.env)
                      xx=0
                      for(ix in 1:length(Xi_)){
                        x=xx+1
                        xx = xx + pop_vect[ix]
                        Xi[x:xx]=Xi_[ix]
                      }
                      Xi=Xi*sum(BoxP)
                      Xi=Xi-(BoxP[1])
                      Xi=10^Xi
                      L=get('L', envir=test.env)
                      n=get('k', envir=test.env)
                      Big_Xi=get('Big_Xi', envir=test.env)
                      Beta=get('Beta', envir=test.env)
                      Self=get('Self', envir=test.env)
                      window_scaling=get('window_scaling', envir=test.env)
                      BW=get('BW', envir=test.env)

                      Pop=get('Pop', envir=test.env)

                      builder=build_HMM_matrix(n,rho_,beta,Pop = Pop,Xi=Xi,L=L,Beta=Beta,scale=window_scaling,sigma = sigma,Sigma = Self)
                      Q=builder[[1]]
                      Q=t(Q)
                      A=as.vector(Q)
                      keep=which(A>0)
                      A=A[keep]
                      Big_Xi=as.vector(Big_Xi)
                      Big_Xi=Big_Xi[keep]
                      Big_M=get('Big_M', envir=test.env)
                      Tc=builder[[3]]
                      g=matrix(0,nrow=length(Tc),ncol=3)
                      g[,3]=1-exp(-mu*2*Tc)
                      g[,2]=1-exp(-mu*2*Tc)
                      g[,1]=exp(-mu*2*Tc)
                      x=as.vector(g)
                      keep=which(x>0)
                      x=x[keep]
                      m=as.vector(Big_M)
                      m=m[keep]
                      q_=get('q_', envir=test.env)
                      nu=builder[[2]]
                      if(BW){
                        LH=-sum(log(A)*Big_Xi)-sum(log(x)*m)-sum(log(nu)*q_)
                      }
                      if(!BW){
                        LH=-sum(log(A)*Big_Xi)
                      }
                      return(LH)
                    }
                    sol= BB::BBoptim(c(oldrho,oldbeta,oldsigma,oldXi_),function_to_minimize,lower=0,upper=1,method=c(2),control = list(maxit=15+length(c(oldrho,oldbeta,oldsigma,oldXi_)),M=c(20)))
                    LH=as.numeric(as.matrix(sol[[2]]))
                    sol=as.matrix(sol[[1]])
                    sol=as.numeric(sol[1:(3+(Klink)),1])
                    rho=sol[1]
                    beta_=sol[2]
                    sigma_=sol[3]
                    Xi_=sol[4:length(sol)]
                    if(LH<oldLH){
                      oldrho=rho
                      oldbeta=beta_
                      oldXi_=Xi_
                      oldsigma=sigma_
                    }


                  }
                }
                if(!SF){
                  if(Popfix){
                    function_to_minimize <-function(param){
                      Boxr=get('Boxr', envir=test.env)
                      mu=get('mu', envir=test.env)
                      sigma=get('sigma',envir = test.env)
                      Self=get('Self',envir = test.env)
                      rho_=param[1]
                      rho_=rho_*sum(Boxr)
                      rho_=rho_-(Boxr[1])
                      rho_=10^(rho_)
                      Rho=get('Rho', envir=test.env)
                      rho_=rho_*Rho
                      BoxB=get('BoxB', envir=test.env)
                      beta=((param[2]*(BoxB[2]-BoxB[1]))+BoxB[1])^2
                      L=get('L', envir=test.env)
                      n=get('k', envir=test.env)
                      Big_Xi=get('Big_Xi', envir=test.env)
                      M=get('M', envir=test.env)
                      Beta=get('Beta', envir=test.env)
                      window_scaling=get('window_scaling', envir=test.env)
                      BW=get('BW', envir=test.env)

                      Pop=get('Pop', envir=test.env)

                      builder=build_HMM_matrix(n,rho_,beta,Pop = Pop,L=L,Beta=Beta,scale=window_scaling,sigma = sigma,Sigma = Self)
                      Q=builder[[1]]
                      Q=t(Q)
                      A=as.vector(Q)
                      keep=which(A>0)
                      A=A[keep]
                      Big_Xi=as.vector(Big_Xi)
                      Big_Xi=Big_Xi[keep]
                      Big_M=get('Big_M', envir=test.env)
                      Tc=builder[[3]]
                      g=matrix(0,nrow=length(Tc),ncol=3)
                      g[,3]=1
                      g[,2]=1-exp(-mu*2*Tc)
                      g[,1]=exp(-mu*2*Tc)
                      x=as.vector(g)
                      keep=which(x>0)
                      x=x[keep]
                      m=as.vector(Big_M)
                      m=m[keep]
                      q_=get('q_', envir=test.env)
                      nu=builder[[2]]
                      if(BW){
                        LH=-sum(log(A)*Big_Xi)-sum(log(x)*m)-sum(log(nu)*q_)
                      }
                      if(!BW){
                        LH=-sum(log(A)*Big_Xi)
                      }
                      return(LH)
                    }
                    sol= BB::BBoptim(c(oldrho,oldbeta), function_to_minimize,lower=0,upper=1,method=c(2),control = list(maxit=15+length(c(oldrho,oldbeta)),M=c(20)))
                    LH=as.numeric(as.matrix(sol[[2]]))
                    sol=as.matrix(sol[[1]])
                    sol=as.numeric(sol[1:2,1])
                    rho=sol[1]
                    beta_=sol[2]

                    if(LH<oldLH){
                      oldrho=rho
                      oldbeta=beta_
                    }
                  }
                  if(!Popfix){
                    function_to_minimize<-function(param){
                      Boxr=get('Boxr', envir=test.env)
                      mu=get('mu', envir=test.env)
                      sigma=get('sigma',envir = test.env)
                      rho_=param[1]
                      rho_=rho_*sum(Boxr)
                      rho_=rho_-(Boxr[1])
                      rho_=10^(rho_)
                      Rho=get('Rho', envir=test.env)
                      rho_=rho_*Rho
                      BoxB=get('BoxB', envir=test.env)
                      beta=((param[2]*(BoxB[2]-BoxB[1]))+BoxB[1])^2
                      BETA=get('BETA',envir=test.env)
                      BoxP=get('BoxP', envir=test.env)
                      Xi_=param[3:length(param)]
                      Xi=vector()
                      pop_vect=get('pop_vect', envir=test.env)
                      xx=0
                      for(ix in 1:length(Xi_)){
                        x=xx+1
                        xx = xx + pop_vect[ix]
                        Xi[x:xx]=Xi_[ix]
                      }
                      Xi=Xi*sum(BoxP)
                      Xi=Xi-(BoxP[1])
                      Xi=10^Xi
                      L=get('L', envir=test.env)
                      n=get('k', envir=test.env)
                      Big_Xi=get('Big_Xi', envir=test.env)
                      Beta=get('Beta', envir=test.env)
                      window_scaling=get('window_scaling', envir=test.env)
                      BW=get('BW', envir=test.env)

                      Pop=get('Pop', envir=test.env)
                      Self=get('Self', envir=test.env)

                      builder=build_HMM_matrix(n,(rho_),beta,Pop = Pop,L=L,Beta=Beta,scale=window_scaling,sigma = sigma,Sigma = Self)
                      Q=builder[[1]]
                      Q=t(Q)
                      A=as.vector(Q)
                      keep=which(A>0)
                      A=A[keep]
                      Big_Xi=as.vector(Big_Xi)
                      Big_Xi=Big_Xi[keep]
                      Big_M=get('Big_M', envir=test.env)
                      Tc=builder[[3]]
                      g=matrix(0,nrow=length(Tc),ncol=3)
                      g[,3]=1
                      g[,2]=1-exp(-mu*2*Tc)
                      g[,1]=exp(-mu*2*Tc)
                      x=as.vector(g)
                      keep=which(x>0)
                      x=x[keep]
                      m=as.vector(Big_M)
                      m=m[keep]
                      q_=get('q_', envir=test.env)
                      nu=builder[[2]]
                      if(BW){
                        LH=-sum(log(A)*Big_Xi)-sum(log(x)*m)-sum(log(nu)*q_)
                      }
                      if(!BW){
                        LH=-sum(log(A)*Big_Xi)
                      }
                      return(LH)
                    }
                    sol= BB::BBoptim(c(oldrho,oldbeta,oldXi_),function_to_minimize,lower=0,upper=1,method=c(2),control = list(maxit=15+length(c(oldrho,oldbeta,oldXi_)),M=c(20)))
                    LH=as.numeric(as.matrix(sol[[2]]))
                    sol=as.matrix(sol[[1]])
                    sol=as.numeric(sol[1:(2+(Klink)),1])
                    rho=sol[1]
                    beta_=sol[2]
                    Xi_=sol[3:length(sol)]
                    if(LH<oldLH){
                      oldrho=rho
                      oldbeta=beta_
                      oldXi_=Xi_
                    }


                  }
                }
              }
              if(!SB){
                if(SF){
                  if(Popfix){
                    function_to_minimize <-function(param){
                      Boxr=get('Boxr', envir=test.env)
                      mu=get('mu', envir=test.env)
                      rho_=param[1]
                      rho_=rho_*sum(Boxr)
                      rho_=rho_-(Boxr[1])
                      rho_=10^(rho_)
                      Rho=get('Rho', envir=test.env)
                      rho_=rho_*Rho
                      beta=get('beta', envir=test.env)
                      L=get('L', envir=test.env)
                      n=get('k', envir=test.env)
                      Big_Xi=get('Big_Xi', envir=test.env)
                      Beta=get('Beta', envir=test.env)
                      window_scaling=get('window_scaling', envir=test.env)
                      Boxs=get('Boxs', envir=test.env)
                      Self=get('Self', envir=test.env)
                      sigma=param[2]
                      sigma=sigma*(Boxs[2]-Boxs[1])
                      sigma=sigma+Boxs[1]
                      sigma=min(sigma,0.99)
                      window_scaling=get('window_scaling', envir=test.env)
                      BW=get('BW', envir=test.env)

                      Pop=get('Pop', envir=test.env)

                      builder=build_HMM_matrix(n,(rho_),beta,Pop = Pop,L=L,Beta=Beta,scale=window_scaling,sigma = sigma,Sigma = Self)
                      Q=builder[[1]]
                      Q=t(Q)
                      A=as.vector(Q)
                      keep=which(A>0)
                      A=A[keep]
                      Big_Xi=as.vector(Big_Xi)
                      Big_Xi=Big_Xi[keep]
                      Big_M=get('Big_M', envir=test.env)
                      Tc=builder[[3]]
                      g=matrix(0,nrow=length(Tc),ncol=3)
                      g[,2]=1-exp(-mu*2*Tc)
                      g[,1]=exp(-mu*2*Tc)
                      g[,3]=1
                      x=as.vector(g)
                      keep=which(x>0)
                      x=x[keep]
                      m=as.vector(Big_M)
                      m=m[keep]
                      q_=get('q_', envir=test.env)
                      nu=builder[[2]]
                      if(BW){
                        LH=-sum(log(A)*Big_Xi)-sum(log(x)*m)-sum(log(nu)*q_)
                      }
                      if(!BW){
                        LH=-sum(log(A)*Big_Xi)
                      }
                      return(LH)
                    }
                    sol= BB::BBoptim(c(oldrho,oldsigma), function_to_minimize,lower=0,upper=1,method=c(2),control = list(maxit=15+length(c(oldrho,oldsigma)),M=c(20)))
                    LH=as.numeric(as.matrix(sol[[2]]))
                    sol=as.matrix(sol[[1]])
                    sol=as.numeric(sol[1:2,1])
                    rho=sol[1]
                    sigma_=sol[2]

                    if(LH<oldLH){
                      oldrho=rho
                      oldsigma=sigma_
                    }
                  }
                  if(!Popfix){
                    function_to_minimize<-function(param){
                      Boxr=get('Boxr', envir=test.env)
                      mu=get('mu', envir=test.env)
                      rho_=param[1]
                      rho_=rho_*sum(Boxr)
                      rho_=rho_-(Boxr[1])
                      rho_=10^(rho_)
                      Rho=get('Rho', envir=test.env)
                      rho_=rho_*Rho
                      beta=get('beta', envir=test.env)
                      BoxP=get('BoxP', envir=test.env)
                      Xi_=param[3:length(param)]
                      Xi=vector()
                      pop_vect=get('pop_vect', envir=test.env)
                      xx=0
                      for(ix in 1:length(Xi_)){
                        x=xx+1
                        xx = xx + pop_vect[ix]
                        Xi[x:xx]=Xi_[ix]
                      }
                      Xi=Xi*sum(BoxP)
                      Xi=Xi-(BoxP[1])
                      Xi=10^Xi
                      L=get('L', envir=test.env)
                      n=get('k', envir=test.env)
                      Big_Xi=get('Big_Xi', envir=test.env)
                      Beta=get('Beta', envir=test.env)
                      window_scaling=get('window_scaling', envir=test.env)
                      Boxs=get('Boxs', envir=test.env)
                      Self=get('Self', envir=test.env)
                      sigma=param[2]
                      sigma=sigma*(Boxs[2]-Boxs[1])
                      sigma=sigma+Boxs[1]
                      sigma=min(sigma,0.99)
                      window_scaling=get('window_scaling', envir=test.env)
                      BW=get('BW', envir=test.env)

                      Pop=get('Pop', envir=test.env)

                      builder=build_HMM_matrix(n,(rho_),beta,Pop = Pop,Xi=Xi,L=L,Beta=Beta,scale=window_scaling,sigma = sigma,Sigma = Self)
                      Q=builder[[1]]
                      Q=t(Q)
                      A=as.vector(Q)
                      keep=which(A>0)
                      A=A[keep]
                      Big_Xi=as.vector(Big_Xi)
                      Big_Xi=Big_Xi[keep]
                      Big_M=get('Big_M', envir=test.env)
                      Tc=builder[[3]]
                      g=matrix(0,nrow=length(Tc),ncol=3)
                      g[,2]=1-exp(-mu*2*Tc)
                      g[,1]=exp(-mu*2*Tc)
                      g[,3]=1
                      x=as.vector(g)
                      keep=which(x>0)
                      x=x[keep]
                      m=as.vector(Big_M)
                      m=m[keep]
                      q_=get('q_', envir=test.env)
                      nu=builder[[2]]
                      if(BW){
                        LH=-sum(log(A)*Big_Xi)-sum(log(x)*m)-sum(log(nu)*q_)
                      }
                      if(!BW){
                        LH=-sum(log(A)*Big_Xi)
                      }
                      return(LH)
                    }
                    sol= BB::BBoptim(c(oldrho,oldsigma,oldXi_),function_to_minimize,lower=0,upper=1,method=c(2),control = list(maxit=15+length(c(oldrho,oldsigma,oldXi_)),M=c(20)))
                    LH=as.numeric(as.matrix(sol[[2]]))
                    sol=as.matrix(sol[[1]])
                    sol=as.numeric(sol[1:(2+(Klink)),1])
                    rho=sol[1]
                    sigma_=sol[2]
                    Xi_=sol[3:length(sol)]
                    if(LH<oldLH){
                      oldrho=rho
                      oldXi_=Xi_
                      oldsigma=sigma_
                    }


                  }
                }
                if(!SF){
                  if(Popfix){
                    function_to_minimize <-function(param){
                      Boxr=get('Boxr', envir=test.env)
                      mu=get('mu', envir=test.env)
                      sigma=get('sigma', envir=test.env)
                      rho_=param[1]
                      rho_=rho_*sum(Boxr)
                      rho_=rho_-(Boxr[1])
                      rho_=10^(rho_)
                      Rho=get('Rho', envir=test.env)
                      rho_=rho_*Rho
                      beta=get('beta', envir=test.env)
                      L=get('L', envir=test.env)
                      n=get('k', envir=test.env)
                      Big_Xi=get('Big_Xi', envir=test.env)
                      Beta=get('Beta', envir=test.env)
                      window_scaling=get('window_scaling', envir=test.env)
                      BW=get('BW', envir=test.env)

                      Pop=get('Pop', envir=test.env)
                      Self=get('Self', envir=test.env)
                      sigma=get('sigma', envir=test.env)

                      builder=build_HMM_matrix(n,(rho_),beta,Pop = Pop,L=L,Beta=Beta,scale=window_scaling,sigma = sigma,Sigma = Self)
                      Q=builder[[1]]
                      Q=t(Q)
                      A=as.vector(Q)
                      keep=which(A>0)
                      A=A[keep]
                      Big_Xi=as.vector(Big_Xi)
                      Big_Xi=Big_Xi[keep]
                      Big_M=get('Big_M', envir=test.env)
                      Tc=builder[[3]]
                      g=matrix(0,nrow=length(Tc),ncol=3)
                      g[,2]=1-exp(-mu*2*Tc)
                      g[,1]=exp(-mu*2*Tc)
                      g[,3]=1
                      x=as.vector(g)
                      keep=which(x>0)
                      x=x[keep]
                      m=as.vector(Big_M)
                      m=m[keep]
                      q_=get('q_', envir=test.env)
                      nu=builder[[2]]
                      if(BW){
                        LH=-sum(log(A)*Big_Xi)-sum(log(x)*m)-sum(log(nu)*q_)
                      }
                      if(!BW){
                        LH=-sum(log(A)*Big_Xi)
                      }
                      return(LH)
                    }
                    sol= BB::BBoptim(c(oldrho),function_to_minimize,lower=0,upper=1,method=c(2),control = list(maxit=15+length(c(oldrho)),M=c(20)))
                    LH=as.numeric(as.matrix(sol[[2]]))
                    sol=as.matrix(sol[[1]])
                    sol=as.numeric(sol[1,1])
                    rho=sol[1]

                    if(LH<oldLH){
                      oldrho=rho
                    }
                  }

                  if(!Popfix){

                    function_to_minimize<-function(param){
                      Boxr=get('Boxr', envir=test.env)
                      mu=get('mu', envir=test.env)
                      sigma=get('sigma', envir=test.env)
                      rho_=param[1]
                      rho_=rho_*sum(Boxr)
                      rho_=rho_-(Boxr[1])
                      rho_=10^(rho_)
                      Rho=get('Rho', envir=test.env)
                      rho_=rho_*Rho
                      beta=get('beta', envir=test.env)
                      BoxP=get('BoxP', envir=test.env)
                      Xi_=param[2:length(param)]
                      Xi=vector()
                      pop_vect=get('pop_vect', envir=test.env)
                      xx=0
                      for(ix in 1:length(Xi_)){
                        x=xx+1
                        xx = xx + pop_vect[ix]
                        Xi[x:xx]=Xi_[ix]
                      }
                      Xi=Xi*sum(BoxP)
                      Xi=Xi-(BoxP[1])
                      Xi=10^Xi
                      L=get('L', envir=test.env)
                      n=get('k', envir=test.env)
                      Big_Xi=get('Big_Xi', envir=test.env)
                      Beta=get('Beta', envir=test.env)
                      window_scaling=get('window_scaling', envir=test.env)
                      BW=get('BW', envir=test.env)

                      Pop=get('Pop', envir=test.env)
                      Self=get('Self', envir=test.env)

                      builder=build_HMM_matrix(n,(rho_),beta,Pop = Pop,Xi=Xi,L=L,Beta=Beta,scale=window_scaling,sigma = sigma,Sigma = Self)
                      Q=builder[[1]]
                      Q=t(Q)
                      A=as.vector(Q)
                      keep=which(A>0)
                      A=A[keep]
                      Big_Xi=as.vector(Big_Xi)
                      Big_Xi=Big_Xi[keep]
                      Big_M=get('Big_M', envir=test.env)
                      Tc=builder[[3]]
                      g=matrix(0,nrow=length(Tc),ncol=3)
                      g[,2]=1-exp(-mu*2*Tc)
                      g[,1]=exp(-mu*2*Tc)
                      g[,3]=1
                      x=as.vector(g)
                      keep=which(x>0)
                      x=x[keep]
                      m=as.vector(Big_M)
                      m=m[keep]
                      q_=get('q_', envir=test.env)
                      nu=builder[[2]]
                      if(BW){
                        LH=-sum(log(A)*Big_Xi)-sum(log(x)*m)-sum(log(nu)*q_)
                      }
                      if(!BW){
                        LH=-sum(log(A)*Big_Xi)
                      }
                      return(LH)
                    }
                    sol= BB::BBoptim(c(oldrho,oldXi_),function_to_minimize,lower=0,upper=1,method=c(2),control = list(maxit=15+length(c(oldrho,oldXi_)),M=c(20)))
                    LH=as.numeric(as.matrix(sol[[2]]))
                    sol=as.matrix(sol[[1]])
                    sol=as.numeric(sol[1:(1+(Klink)),1])
                    rho=sol[1]
                    Xi_=sol[2:length(sol)]
                    if(LH<oldLH){
                      oldrho=rho
                      oldXi_=Xi_
                    }


                  }
                }
              }
            }
            if(!ER){
              if(SB){
                if(SF){
                  if(Popfix){
                    function_to_minimize <-function(param){
                      Boxr=get('Boxr', envir=test.env)
                      mu=get('mu', envir=test.env)
                      Rho=get('Rho', envir=test.env)
                      rho_=Rho
                      BoxB=get('BoxB', envir=test.env)
                      beta=((param[1]*(BoxB[2]-BoxB[1]))+BoxB[1])^2
                      L=get('L', envir=test.env)
                      n=get('k', envir=test.env)
                      Big_Xi=get('Big_Xi', envir=test.env)
                      Big_M=get('Big_M', envir=test.env)
                      Beta=get('Beta', envir=test.env)
                      Boxs=get('Boxs', envir=test.env)
                      Self=get('Self', envir=test.env)
                      sigma=param[2]
                      sigma=sigma*(Boxs[2]-Boxs[1])
                      sigma=sigma+Boxs[1]
                      sigma=min(sigma,0.99)
                      window_scaling=get('window_scaling', envir=test.env)
                      BW=get('BW', envir=test.env)

                      Pop=get('Pop', envir=test.env)

                      builder=build_HMM_matrix(n,(rho_),beta,Pop = Pop,L=L,Beta=Beta,scale=window_scaling,sigma = sigma,Sigma = Self)
                      Q=builder[[1]]
                      Q=t(Q)
                      A=as.vector(Q)
                      keep=which(A>0)
                      A=A[keep]
                      Big_Xi=as.vector(Big_Xi)
                      Big_Xi=Big_Xi[keep]
                      Tc=builder[[3]]
                      g=matrix(0,nrow=length(Tc),ncol=3)
                      g[,2]=1-exp(-mu*2*Tc)
                      g[,1]=exp(-mu*2*Tc)
                      g[,3]=1
                      x=as.vector(g)
                      keep=which(x>0)
                      x=x[keep]
                      m=as.vector(Big_M)
                      m=m[keep]
                      q_=get('q_', envir=test.env)
                      nu=builder[[2]]
                      if(BW){
                        LH=-sum(log(A)*Big_Xi)-sum(log(x)*m)-sum(log(nu)*q_)
                      }
                      if(!BW){
                        LH=-sum(log(A)*Big_Xi)
                      }
                      return(LH)
                    }
                    sol= BB::BBoptim(c(oldbeta,oldsigma),function_to_minimize,lower=0,upper=1,method=c(2),control = list(maxit=15+length(c(oldbeta,oldsigma)),M=c(20)))
                    LH=as.numeric(as.matrix(sol[[2]]))
                    sol=as.matrix(sol[[1]])
                    sol=as.numeric(sol[1:2,1])
                    beta_=sol[1]
                    sigma_=sol[2]

                    if(LH<oldLH){
                      oldbeta=beta_
                      oldsigma=sigma_
                    }
                  }
                  if(!Popfix){
                    function_to_minimize<-function(param){
                      Boxr=get('Boxr', envir=test.env)
                      mu=get('mu', envir=test.env)
                      Rho=get('Rho', envir=test.env)
                      rho_=Rho
                      BoxB=get('BoxB', envir=test.env)
                      Boxs=get('Boxs', envir=test.env)
                      beta=((param[1]*(BoxB[2]-BoxB[1]))+BoxB[1])^2
                      BoxP=get('BoxP', envir=test.env)
                      sigma=param[2]
                      sigma=sigma*(Boxs[2]-Boxs[1])
                      sigma=sigma+Boxs[1]
                      sigma=min(sigma,0.99)
                      Xi_=param[3:length(param)]
                      Xi=vector()
                      pop_vect=get('pop_vect', envir=test.env)
                      xx=0
                      for(ix in 1:length(Xi_)){
                        x=xx+1
                        xx = xx + pop_vect[ix]
                        Xi[x:xx]=Xi_[ix]
                      }
                      Xi=Xi*sum(BoxP)
                      Xi=Xi-(BoxP[1])
                      Xi=10^Xi
                      L=get('L', envir=test.env)
                      n=get('k', envir=test.env)
                      Big_Xi=get('Big_Xi', envir=test.env)
                      Beta=get('Beta', envir=test.env)
                      Self=get('Self', envir=test.env)
                      window_scaling=get('window_scaling', envir=test.env)
                      BW=get('BW', envir=test.env)

                      Pop=get('Pop', envir=test.env)

                      builder=build_HMM_matrix(n,(rho_),beta,Pop = Pop,Xi=Xi,L=L,Beta=Beta,scale=window_scaling,sigma = sigma,Sigma = Self)
                      Q=builder[[1]]
                      Q=t(Q)
                      A=as.vector(Q)
                      keep=which(A>0)
                      A=A[keep]
                      Big_Xi=as.vector(Big_Xi)
                      Big_Xi=Big_Xi[keep]
                      Big_M=get('Big_M', envir=test.env)
                      Tc=builder[[3]]
                      g=matrix(0,nrow=length(Tc),ncol=3)
                      g[,2]=1-exp(-mu*2*Tc)
                      g[,1]=exp(-mu*2*Tc)
                      g[,3]=1
                      x=as.vector(g)
                      keep=which(x>0)
                      x=x[keep]
                      m=as.vector(Big_M)
                      m=m[keep]
                      q_=get('q_', envir=test.env)
                      nu=builder[[2]]
                      if(BW){
                        LH=-sum(log(A)*Big_Xi)-sum(log(x)*m)-sum(log(nu)*q_)
                      }
                      if(!BW){
                        LH=-sum(log(A)*Big_Xi)
                      }
                      return(LH)
                    }
                    sol= BB::BBoptim(c(oldbeta,oldsigma,oldXi_),function_to_minimize,lower=0,upper=1,method=c(2),control = list(maxit=15+length(c(oldbeta,oldsigma,oldXi_)),M=c(20)))
                    LH=as.numeric(as.matrix(sol[[2]]))
                    sol=as.matrix(sol[[1]])
                    sol=as.numeric(sol[1:(2+(Klink)),1])
                    beta_=sol[1]
                    sigma_=sol[2]
                    Xi_=sol[3:length(sol)]
                    if(LH<oldLH){
                      oldbeta=beta_
                      oldXi_=Xi_
                      oldsigma=sigma_
                    }


                  }
                }
                if(!SF){
                  if(Popfix){
                    function_to_minimize <-function(param){
                      Boxr=get('Boxr', envir=test.env)
                      sigma=get('sigma', envir=test.env)
                      mu=get('mu', envir=test.env)
                      Rho=get('Rho', envir=test.env)
                      rho_=Rho
                      BoxB=get('BoxB', envir=test.env)
                      beta=((param[1]*(BoxB[2]-BoxB[1]))+BoxB[1])^2
                      L=get('L', envir=test.env)
                      n=get('k', envir=test.env)
                      Big_Xi=get('Big_Xi', envir=test.env)
                      M=get('M', envir=test.env)
                      Beta=get('Beta', envir=test.env)
                      window_scaling=get('window_scaling', envir=test.env)
                      BW=get('BW', envir=test.env)

                      Pop=get('Pop', envir=test.env)
                      Self=get('Self', envir=test.env)

                      builder=build_HMM_matrix(n,(rho_),beta,Pop = Pop,L=L,Beta=Beta,scale=window_scaling,sigma = sigma,Sigma = Self)
                      Q=builder[[1]]
                      Q=t(Q)
                      A=as.vector(Q)
                      keep=which(A>0)
                      A=A[keep]
                      Big_Xi=as.vector(Big_Xi)
                      Big_Xi=Big_Xi[keep]
                      Big_M=get('Big_M', envir=test.env)
                      Tc=builder[[3]]
                      g=matrix(0,nrow=length(Tc),ncol=3)
                      g[,2]=1-exp(-mu*2*Tc)
                      g[,1]=exp(-mu*2*Tc)
                      g[,3]=1
                      x=as.vector(g)
                      keep=which(x>0)
                      x=x[keep]
                      m=as.vector(Big_M)
                      m=m[keep]
                      q_=get('q_', envir=test.env)
                      nu=builder[[2]]
                      if(BW){
                        LH=-sum(log(A)*Big_Xi)-sum(log(x)*m)-sum(log(nu)*q_)
                      }
                      if(!BW){
                        LH=-sum(log(A)*Big_Xi)
                      }
                      return(LH)
                    }
                    sol= BB::BBoptim(c(oldbeta),function_to_minimize,lower=0,upper=1,method=c(2),control = list(maxit=15+length(c(oldbeta)),M=c(20)))
                    LH=as.numeric(as.matrix(sol[[2]]))
                    sol=as.matrix(sol[[1]])
                    sol=as.numeric(sol[1,1])
                    beta_=sol[1]

                    if(LH<oldLH){
                      oldbeta=beta_
                    }
                  }
                  if(!Popfix){
                    function_to_minimize<-function(param){
                      mu=get('mu', envir=test.env)
                      Rho=get('Rho', envir=test.env)
                      sigma=get('sigma', envir=test.env)
                      rho_=Rho
                      BoxB=get('BoxB', envir=test.env)
                      beta=((param[1]*(BoxB[2]-BoxB[1]))+BoxB[1])^2
                      BoxP=get('BoxP', envir=test.env)
                      Xi_=param[2:length(param)]
                      Xi=vector()
                      pop_vect=get('pop_vect', envir=test.env)
                      xx=0
                      for(ix in 1:length(Xi_)){
                        x=xx+1
                        xx = xx + pop_vect[ix]
                        Xi[x:xx]=Xi_[ix]
                      }
                      Xi=Xi*sum(BoxP)
                      Xi=Xi-(BoxP[1])
                      Xi=10^Xi
                      L=get('L', envir=test.env)
                      n=get('k', envir=test.env)
                      Big_Xi=get('Big_Xi', envir=test.env)
                      Beta=get('Beta', envir=test.env)
                      window_scaling=get('window_scaling', envir=test.env)
                      BW=get('BW', envir=test.env)
                      Pop=get('Pop', envir=test.env)
                      Self=get('Self', envir=test.env)

                      builder=build_HMM_matrix(n,(rho_),beta,Pop = Pop,Xi=Xi,L=L,Beta=Beta,scale=window_scaling,sigma = sigma,Sigma = Self) #
                      Q=builder[[1]]
                      Q=t(Q)
                      A=as.vector(Q)
                      keep=which(A>0)
                      A=A[keep]
                      Big_Xi=as.vector(Big_Xi)
                      Big_Xi=Big_Xi[keep]
                      Big_M=get('Big_M', envir=test.env)
                      Tc=builder[[3]]
                      g=matrix(0,nrow=length(Tc),ncol=3)
                      g[,2]=1-exp(-mu*2*Tc)
                      g[,1]=exp(-mu*2*Tc)
                      g[,3]=1
                      x=as.vector(g)
                      keep=which(x>0)
                      x=x[keep]
                      m=as.vector(Big_M)
                      m=m[keep]
                      q_=get('q_', envir=test.env)
                      nu=builder[[2]]
                      if(BW){
                        LH=-sum(log(A)*Big_Xi)-sum(log(x)*m)-sum(log(nu)*q_)
                      }
                      if(!BW){
                        LH=-sum(log(A)*Big_Xi)
                      }
                      return(LH)
                    }
                    sol= BB::BBoptim(c(oldbeta,oldXi_),function_to_minimize,lower=0,upper=1,method=c(2),control = list(maxit=15+length(c(oldbeta,oldXi_)),M=c(20)))
                    LH=as.numeric(as.matrix(sol[[2]]))
                    sol=as.matrix(sol[[1]])
                    sol=as.numeric(sol[1:(1+(Klink)),1])
                    beta_=sol[1]
                    Xi_=sol[2:length(sol)]
                    if(LH<oldLH){
                      oldbeta=beta_
                      oldXi_=Xi_
                    }


                  }
                }
              }
              if(!SB){
                if(SF){
                  if(Popfix){
                    function_to_minimize <-function(param){
                      Boxr=get('Boxr', envir=test.env)
                      mu=get('mu', envir=test.env)
                      Rho=get('Rho', envir=test.env)
                      rho_=Rho
                      beta=get('beta', envir=test.env)
                      L=get('L', envir=test.env)
                      n=get('k', envir=test.env)
                      Big_Xi=get('Big_Xi', envir=test.env)
                      Beta=get('Beta', envir=test.env)
                      window_scaling=get('window_scaling', envir=test.env)
                      Boxs=get('Boxs', envir=test.env)
                      Self=get('Self', envir=test.env)
                      sigma=param[1]
                      sigma=sigma*(Boxs[2]-Boxs[1])
                      sigma=sigma+Boxs[1]
                      sigma=min(sigma,0.99)
                      window_scaling=get('window_scaling', envir=test.env)
                      BW=get('BW', envir=test.env)

                      Pop=get('Pop', envir=test.env)

                      builder=build_HMM_matrix(n,(rho_),beta,Pop = Pop,L=L,Beta=Beta,scale=window_scaling,sigma = sigma,Sigma = Self)
                      Q=builder[[1]]
                      Q=t(Q)
                      A=as.vector(Q)
                      keep=which(A>0)
                      A=A[keep]
                      Big_Xi=as.vector(Big_Xi)
                      Big_Xi=Big_Xi[keep]
                      Big_M=get('Big_M', envir=test.env)
                      Tc=builder[[3]]
                      g=matrix(0,nrow=length(Tc),ncol=3)
                      g[,2]=1-exp(-mu*2*Tc)
                      g[,1]=exp(-mu*2*Tc)
                      g[,3]=1
                      x=as.vector(g)
                      keep=which(x>0)
                      x=x[keep]
                      m=as.vector(Big_M)
                      m=m[keep]
                      q_=get('q_', envir=test.env)
                      nu=builder[[2]]
                      if(BW){
                        LH=-sum(log(A)*Big_Xi)-sum(log(x)*m)-sum(log(nu)*q_)
                      }
                      if(!BW){
                        LH=-sum(log(A)*Big_Xi)
                      }
                      return(LH)
                    }
                    sol= BB::BBoptim(c(oldsigma),function_to_minimize,lower=0,upper=1,method=c(2),control = list(maxit=15+length(c(oldsigma)),M=c(20)))
                    LH=as.numeric(as.matrix(sol[[2]]))
                    sol=as.matrix(sol[[1]])
                    sol=as.numeric(sol[1,1])
                    sigma_=sol[1]

                    if(LH<oldLH){
                      oldsigma=sigma_
                    }
                  }

                  if(!Popfix){

                    function_to_minimize<-function(param){
                      Boxr=get('Boxr', envir=test.env)
                      Rho=get('Rho', envir=test.env)
                      mu=get('mu', envir=test.env)
                      rho_=Rho
                      beta=get('beta', envir=test.env)
                      BoxP=get('BoxP', envir=test.env)
                      Xi_=param[2:length(param)]
                      Xi=vector()
                      pop_vect=get('pop_vect', envir=test.env)
                      xx=0
                      for(ix in 1:length(Xi_)){
                        x=xx+1
                        xx = xx + pop_vect[ix]
                        Xi[x:xx]=Xi_[ix]
                      }
                      Xi=Xi*sum(BoxP)
                      Xi=Xi-(BoxP[1])
                      Xi=10^Xi
                      L=get('L', envir=test.env)
                      n=get('k', envir=test.env)
                      Big_Xi=get('Big_Xi', envir=test.env)
                      Beta=get('Beta', envir=test.env)
                      window_scaling=get('window_scaling', envir=test.env)
                      Boxs=get('Boxs', envir=test.env)
                      Self=get('Self', envir=test.env)
                      sigma=param[1]
                      sigma=sigma*(Boxs[2]-Boxs[1])
                      sigma=sigma+Boxs[1]
                      sigma=min(sigma,0.99)
                      window_scaling=get('window_scaling', envir=test.env)
                      BW=get('BW', envir=test.env)

                      Pop=get('Pop', envir=test.env)

                      builder=build_HMM_matrix(n,(rho_),beta,Pop = Pop,Xi=Xi,L=L,Beta=Beta,scale=window_scaling,sigma = sigma,Sigma = Self)
                      Q=builder[[1]]
                      Q=t(Q)
                      A=as.vector(Q)
                      keep=which(A>0)
                      A=A[keep]
                      Big_Xi=as.vector(Big_Xi)
                      Big_Xi=Big_Xi[keep]
                      Big_M=get('Big_M', envir=test.env)
                      Tc=builder[[3]]
                      g=matrix(0,nrow=length(Tc),ncol=3)
                      g[,2]=1-exp(-mu*2*Tc)
                      g[,1]=exp(-mu*2*Tc)
                      g[,3]=1
                      x=as.vector(g)
                      keep=which(x>0)
                      x=x[keep]
                      m=as.vector(Big_M)
                      m=m[keep]
                      q_=get('q_', envir=test.env)
                      nu=builder[[2]]
                      if(BW){
                        LH=-sum(log(A)*Big_Xi)-sum(log(x)*m)-sum(log(nu)*q_)
                      }
                      if(!BW){
                        LH=-sum(log(A)*Big_Xi)
                      }
                      return(LH)
                    }
                    sol= BB::BBoptim(c(oldsigma,oldXi_),function_to_minimize,lower=0,upper=1,method=c(2),control = list(maxit=15+length(c(oldsigma,oldXi_)),M=c(20)))
                    LH=as.numeric(as.matrix(sol[[2]]))
                    sol=as.matrix(sol[[1]])
                    sol=as.numeric(sol[1:(1+(Klink)),1])
                    sigma_=sol[1]
                    Xi_=sol[2:length(sol)]
                    if(LH<oldLH){
                      oldXi_=Xi_
                      oldsigma=sigma_
                    }


                  }
                }
                if(!SF){
                  if(!Popfix){
                    function_to_minimize<-function(param){
                      Boxr=get('Boxr', envir=test.env)
                      mu=get('mu', envir=test.env)
                      sigma=get('sigma', envir=test.env)
                      Rho=get('Rho', envir=test.env)
                      rho_=Rho
                      beta=get('beta', envir=test.env)
                      BoxP=get('BoxP', envir=test.env)
                      Xi_=param[1:length(param)]
                      Xi=vector()
                      pop_vect=get('pop_vect', envir=test.env)
                      xx=0
                      for(ix in 1:length(Xi_)){
                        x=xx+1
                        xx = xx + pop_vect[ix]
                        Xi[x:xx]=Xi_[ix]
                      }
                      Xi=Xi*sum(BoxP)
                      Xi=Xi-(BoxP[1])
                      Xi=10^Xi
                      L=get('L', envir=test.env)
                      n=get('k', envir=test.env)
                      Big_Xi=get('Big_Xi', envir=test.env)
                      Beta=get('Beta', envir=test.env)
                      window_scaling=get('window_scaling', envir=test.env)
                      BW=get('BW', envir=test.env)

                      Pop=get('Pop', envir=test.env)
                      Self=get('Self', envir=test.env)

                      builder=build_HMM_matrix(n,(rho_),beta,Pop = Pop,Xi=Xi,L=L,Beta=Beta,scale=window_scaling,sigma = sigma,Sigma = Self)
                      Q=builder[[1]]
                      Q=t(Q)
                      A=as.vector(Q)
                      keep=which(A>0)
                      A=A[keep]
                      Big_Xi=as.vector(Big_Xi)
                      Big_Xi=Big_Xi[keep]
                      Big_M=get('Big_M', envir=test.env)
                      Tc=builder[[3]]
                      g=matrix(0,nrow=length(Tc),ncol=3)
                      g[,2]=1-exp(-mu*2*Tc)
                      g[,1]=exp(-mu*2*Tc)
                      g[,3]=1
                      x=as.vector(g)
                      keep=which(x>0)
                      x=x[keep]
                      m=as.vector(Big_M)
                      m=m[keep]
                      q_=get('q_', envir=test.env)
                      nu=builder[[2]]
                      if(BW){
                        LH=-sum(log(A)*Big_Xi)-sum(log(x)*m)-sum(log(nu)*q_)
                      }
                      if(!BW){
                        LH=-sum(log(A)*Big_Xi)
                      }
                      return(LH)
                    }
                    sol= BB::BBoptim(c(oldXi_),function_to_minimize,lower=0,upper=1,method=c(2),control = list(maxit=15+length(c(oldXi_)),M=c(20)))
                    LH=as.numeric(as.matrix(sol[[2]]))
                    sol=as.matrix(sol[[1]])
                    sol=as.numeric(sol[1:((Klink)),1])
                    Xi_=sol[1:length(sol)]
                    if(LH<oldLH){
                      oldXi_=Xi_
                    }


                  }
                }


              }
            }
          }
          if(NC>1){
            if(ER){
              if(SB){
                if(SF){
                  if(Popfix){
                    function_to_minimize <-function(param){
                      Boxr=get('Boxr', envir=test.env)
                      mu=get('mu', envir=test.env)
                      NC=get('NC', envir=test.env)
                      lr=get('lr', envir=test.env)
                      rho_=param[1:lr]
                      rho_=rho_*sum(Boxr)
                      rho_=rho_-(Boxr[1])
                      rho_=10^(rho_)
                      Rho=get('Rho', envir=test.env)
                      rho_=rho_*Rho
                      BoxB=get('BoxB', envir=test.env)
                      beta=((param[(lr+1)]*(BoxB[2]-BoxB[1]))+BoxB[1])^2
                      L=get('L', envir=test.env)
                      n=get('k', envir=test.env)
                      Big_Xi=get('Big_Xi', envir=test.env)
                      Big_M=get('Big_M', envir=test.env)
                      Beta=get('Beta', envir=test.env)
                      Boxs=get('Boxs', envir=test.env)
                      Self=get('Self', envir=test.env)
                      sigma=param[lr+2]
                      sigma=sigma*(Boxs[2]-Boxs[1])
                      sigma=sigma+Boxs[1]
                      sigma=min(sigma,0.99)
                      window_scaling=get('window_scaling', envir=test.env)
                      BW=get('BW', envir=test.env)
                      Pop=get('Pop', envir=test.env)
                      Share_r=get('Share_r', envir=test.env)
                      LH=0
                      if(Share_r){
                          builder=build_HMM_matrix(n,(rho_[1]),beta,Pop = Pop,L=L[1],Beta=Beta,scale=window_scaling,sigma = sigma,Sigma = Self)
                          Q=builder[[1]]
                          Q=t(Q)
                          A=as.vector(Q)
                          keep=which(A>0)
                          A=A[keep]
                          Big_Xi=as.vector(Big_Xi)
                          Big_Xi=Big_Xi[keep]
                          Tc=builder[[3]]
                          g=matrix(0,nrow=length(Tc),ncol=3)
                          g[,2]=1-exp(-mu*2*Tc)
                          g[,1]=exp(-mu*2*Tc)
                          g[,3]=1
                          x=as.vector(g)
                          keep=which(x>0)
                          x=x[keep]
                          m=as.vector(Big_M)
                          m=m[keep]
                          q_=get('q_', envir=test.env)
                          nu=builder[[2]]
                          if(BW){
                            LH=LH-sum(log(A)*Big_Xi)-sum(log(x)*m)-sum(log(nu)*q_)
                          }
                          if(!BW){
                            LH=LH-sum(log(A)*Big_Xi)
                          }

                      }else{
                        for(chr in 1:NC){
                          builder=build_HMM_matrix(n,(rho_[chr]),beta,Pop = Pop,L=L[chr],Beta=Beta,scale=window_scaling,sigma = sigma,Sigma = Self)
                          Q=builder[[1]]
                          Q=t(Q)
                          A=as.vector(Q)
                          keep=which(A>0)
                          A=A[keep]
                          Big_Xi[[chr]]=as.vector(Big_Xi[[chr]])
                          Big_Xi[[chr]]=Big_Xi[[chr]][keep]
                          Tc=builder[[3]]
                          g=matrix(0,nrow=length(Tc),ncol=3)
                          g[,2]=1-exp(-mu[chr]*2*Tc)
                          g[,1]=exp(-mu[chr]*2*Tc)
                          g[,3]=1
                          x=as.vector(g)
                          keep=which(x>0)
                          x=x[keep]
                          m=as.vector(Big_M[[chr]])
                          m=m[keep]
                          q_=get('q_', envir=test.env)
                          nu=builder[[2]]
                          if(BW){
                            LH=LH-sum(log(A)*Big_Xi[[chr]])-sum(log(x)*m)-sum(log(nu)*q_[[chr]])
                          }
                          if(!BW){
                            LH=LH-sum(log(A)*Big_Xi[[chr]])
                          }
                        }
                      }

                      return(LH)
                    }
                    sol= BB::BBoptim(c(oldrho,oldbeta,oldsigma),function_to_minimize,lower=0,upper=1,method=c(2),control = list(maxit=30,M=c(20)))
                    LH=as.numeric(as.matrix(sol[[2]]))
                    sol=as.matrix(sol[[1]])
                    sol=as.numeric(sol[1:(length(oldrho)+2),1])
                    rho=sol[1:length(oldrho)]
                    beta_=sol[length(oldrho)+1]
                    sigma_=sol[length(oldrho)+2]
                    oldrho=rho
                    oldbeta=beta_
                    oldsigma=sigma_
                  }
                  if(!Popfix){
                    function_to_minimize_optim<-function(param){
                      Boxr=get('Boxr', envir=test.env)
                      mu=get('mu', envir=test.env)
                      NC=get('NC', envir=test.env)
                      lr=get('lr', envir=test.env)
                      rho_=param[1:lr]
                      rho_=rho_*sum(Boxr)
                      rho_=rho_-(Boxr[1])
                      rho_=10^(rho_)
                      Rho=get('Rho', envir=test.env)
                      rho_=rho_*Rho
                      BoxB=get('BoxB', envir=test.env)
                      Boxs=get('Boxs', envir=test.env)
                      beta=((param[(lr+1)]*(BoxB[2]-BoxB[1]))+BoxB[1])^2
                      BoxP=get('BoxP', envir=test.env)
                      sigma=param[lr+2]
                      sigma=sigma*(Boxs[2]-Boxs[1])
                      sigma=sigma+Boxs[1]
                      sigma=min(sigma,0.99)
                      Xi_=param[3+lr:length(param)]
                      Xi=vector()
                      pop_vect=get('pop_vect', envir=test.env)
                      xx=0
                      for(ix in 1:length(Xi_)){
                        x=xx+1
                        xx = xx + pop_vect[ix]
                        Xi[x:xx]=Xi_[ix]
                      }
                      Xi=Xi*sum(BoxP)
                      Xi=Xi-(BoxP[1])
                      Xi=10^Xi
                      L=get('L', envir=test.env)
                      n=get('k', envir=test.env)
                      Big_Xi=get('Big_Xi', envir=test.env)
                      Beta=get('Beta', envir=test.env)
                      Self=get('Self', envir=test.env)
                      window_scaling=get('window_scaling', envir=test.env)
                      BW=get('BW', envir=test.env)
                      Share_r=get('Share_r', envir=test.env)
                      Pop=get('Pop', envir=test.env)
                      Big_M=get('Big_M', envir=test.env)
                      LH=0
                      if(Share_r){
                          builder=build_HMM_matrix(n,(rho_[1]),beta,Pop = Pop,Xi=Xi,L=L[1],Beta=Beta,scale=window_scaling,sigma = sigma,Sigma = Self)
                          Q=builder[[1]]
                          Q=t(Q)
                          A=as.vector(Q)
                          keep=which(A>0)
                          A=A[keep]
                          Big_Xi=as.vector(Big_Xi)
                          Big_Xi=Big_Xi[keep]
                          Tc=builder[[3]]
                          g=matrix(0,nrow=length(Tc),ncol=3)
                          g[,2]=1-exp(-mu*2*Tc)
                          g[,1]=exp(-mu*2*Tc)
                          g[,3]=1
                          x=as.vector(g)
                          keep=which(x>0)
                          x=x[keep]
                          m=as.vector(Big_M)
                          m=m[keep]
                          q_=get('q_', envir=test.env)
                          nu=builder[[2]]
                          if(BW){
                            LH=LH-sum(log(A)*Big_Xi)-sum(log(x)*m)-sum(log(nu)*q_)
                          }
                          if(!BW){
                            LH=LH-sum(log(A)*Big_Xi)
                          }

                      }else{

                        for(chr in 1:NC){
                          builder=build_HMM_matrix(n,(rho_[chr]),beta,Pop = Pop,Xi=Xi,L=L[chr],Beta=Beta,scale=window_scaling,sigma = sigma,Sigma = Self)
                          Q=builder[[1]]
                          Q=t(Q)
                          A=as.vector(Q)
                          keep=which(A>0)
                          A=A[keep]
                          Big_Xi[[chr]]=as.vector(Big_Xi[[chr]])
                          Big_Xi[[chr]]=Big_Xi[[chr]][keep]
                          Tc=builder[[3]]
                          g=matrix(0,nrow=length(Tc),ncol=3)
                          g[,2]=1-exp(-mu[chr]*2*Tc)
                          g[,1]=exp(-mu[chr]*2*Tc)
                          g[,3]=1
                          x=as.vector(g)
                          keep=which(x>0)
                          x=x[keep]
                          m=as.vector(Big_M[[chr]])
                          m=m[keep]
                          q_=get('q_', envir=test.env)
                          nu=builder[[2]]
                          if(BW){
                            LH=LH-sum(log(A)*Big_Xi[[chr]])-sum(log(x)*m)-sum(log(nu)*q_[[chr]])
                          }
                          if(!BW){
                            LH=LH-sum(log(A)*Big_Xi[[chr]])
                          }
                        }
                      }

                      return(LH)
                    }
                    sol= BB::BBoptim(c(oldrho,oldbeta,oldsigma,oldXi_),function_to_minimize_optim,lower=0,upper=1,method=c(2),control = list(maxit=30,M=c(20)))
                    LH=as.numeric(as.matrix(sol[[2]]))
                    sol=as.matrix(sol[[1]])
                    sol=as.numeric(sol[1:(2+length(oldrho)+(Klink)),1])
                    rho=sol[1:length(oldrho)]
                    beta_=sol[length(oldrho)+1]
                    sigma_=sol[length(oldrho)+2]
                    Xi_=sol[(length(oldrho)+3):length(sol)]
                    oldrho=rho
                    oldbeta=beta_
                    oldXi_=Xi_
                    oldsigma=sigma_

                  }
                }
                if(!SF){
                  if(Popfix){
                    function_to_minimize <-function(param){
                      Boxr=get('Boxr', envir=test.env)
                      mu=get('mu', envir=test.env)
                      NC=get('NC', envir=test.env)
                      lr=get('lr', envir=test.env)
                      rho_=param[1:lr]
                      rho_=rho_*sum(Boxr)
                      rho_=rho_-(Boxr[1])
                      rho_=10^(rho_)
                      Rho=get('Rho', envir=test.env)
                      rho_=rho_*Rho
                      BoxB=get('BoxB', envir=test.env)
                      beta=((param[(lr+1)]*(BoxB[2]-BoxB[1]))+BoxB[1])^2
                      L=get('L', envir=test.env)
                      n=get('k', envir=test.env)
                      Big_Xi=get('Big_Xi', envir=test.env)
                      M=get('M', envir=test.env)
                      Beta=get('Beta', envir=test.env)
                      window_scaling=get('window_scaling', envir=test.env)
                      BW=get('BW', envir=test.env)
                      Share_r=get('Share_r', envir=test.env)
                      Pop=get('Pop', envir=test.env)
                      Big_M=get('Big_M', envir=test.env)
                      LH=0
                      Self=get('Self', envir=test.env)
                      sigma=get('sigma', envir=test.env)
                      if(Share_r){
                        builder=build_HMM_matrix(n,(rho_[1]),beta,Pop = Pop,L=L[1],Beta=Beta,scale=window_scaling,sigma = sigma,Sigma = Self)
                        Q=builder[[1]]
                        Q=t(Q)
                        A=as.vector(Q)
                        keep=which(A>0)
                        A=A[keep]
                        Big_Xi=as.vector(Big_Xi)
                        Big_Xi=Big_Xi[keep]
                        Tc=builder[[3]]
                        g=matrix(0,nrow=length(Tc),ncol=3)
                        g[,2]=1-exp(-mu*2*Tc)
                        g[,1]=exp(-mu*2*Tc)
                        g[,3]=1
                        x=as.vector(g)
                        keep=which(x>0)
                        x=x[keep]
                        m=as.vector(Big_M)
                        m=m[keep]
                        q_=get('q_', envir=test.env)
                        nu=builder[[2]]
                        if(BW){
                          LH=LH-sum(log(A)*Big_Xi)-sum(log(x)*m)-sum(log(nu)*q_)}
                        if(!BW){
                          LH=LH-sum(log(A)*Big_Xi)
                        }
                      }else{
                        for(chr in 1:NC){
                          builder=build_HMM_matrix(n,(rho_[chr]),beta,Pop = Pop,L=L[chr],Beta=Beta,scale=window_scaling,sigma = sigma,Sigma = Self)
                          Q=builder[[1]]
                          Q=t(Q)
                          A=as.vector(Q)
                          keep=which(A>0)
                          A=A[keep]
                          Big_Xi[[chr]]=as.vector(Big_Xi[[chr]])
                          Big_Xi[[chr]]=Big_Xi[[chr]][keep]
                          Tc=builder[[3]]
                          g=matrix(0,nrow=length(Tc),ncol=3)
                          g[,2]=1-exp(-mu[chr]*2*Tc)
                          g[,1]=exp(-mu[chr]*2*Tc)
                          g[,3]=1
                          x=as.vector(g)
                          keep=which(x>0)
                          x=x[keep]
                          m=as.vector(Big_M[[chr]])
                          m=m[keep]
                          q_=get('q_', envir=test.env)
                          nu=builder[[2]]
                          if(BW){
                            LH=LH-sum(log(A)*Big_Xi[[chr]])-sum(log(x)*m)-sum(log(nu)*q_[[chr]])}
                          if(!BW){
                            LH=LH-sum(log(A)*Big_Xi[[chr]])
                          }

                        }
                      }

                      return(LH)
                    }
                    sol= BB::BBoptim(c(oldrho,oldbeta),function_to_minimize,lower=0,upper=1,method=c(2),control = list(maxit=30,M=c(20)))
                    LH=as.numeric(as.matrix(sol[[2]]))
                    sol=as.matrix(sol[[1]])
                    sol=as.numeric(sol[1:(length(oldrho)+1),1])
                    rho=sol[1:length(oldrho)]
                    beta_=sol[length(oldrho)+1]
                    oldrho=rho
                    oldbeta=beta_
                  }
                  if(!Popfix){
                    function_to_minimize_optim<-function(param){
                      Boxr=get('Boxr', envir=test.env)
                      mu=get('mu', envir=test.env)
                      NC=get('NC',envir=test.env)
                      lr=get('lr', envir=test.env)
                      rho_=param[1:lr]
                      rho_=rho_*sum(Boxr)
                      rho_=rho_-(Boxr[1])
                      rho_=10^(rho_)
                      Rho=get('Rho', envir=test.env)
                      rho_=rho_*Rho
                      BoxB=get('BoxB', envir=test.env)
                      beta=((param[(lr+1)]*(BoxB[2]-BoxB[1]))+BoxB[1])^2
                      BoxP=get('BoxP', envir=test.env)
                      Xi_=param[(lr+2):length(param)]
                      Xi=vector()
                      pop_vect=get('pop_vect', envir=test.env)
                      xx=0
                      for(ix in 1:length(Xi_)){
                        x=xx+1
                        xx = xx + pop_vect[ix]
                        Xi[x:xx]=Xi_[ix]
                      }
                      Xi=Xi*sum(BoxP)
                      Xi=Xi-(BoxP[1])
                      Xi=10^Xi
                      L=get('L', envir=test.env)
                      n=get('k', envir=test.env)
                      Big_Xi=get('Big_Xi', envir=test.env)
                      Big_M=get('Big_M', envir=test.env)
                      Beta=get('Beta', envir=test.env)
                      window_scaling=get('window_scaling', envir=test.env)
                      BW=get('BW', envir=test.env)
                      Share_r=get('Share_r', envir=test.env)
                      Pop=get('Pop', envir=test.env)
                      LH=0
                      Self=get('Self', envir=test.env)
                      sigma=get('sigma', envir=test.env)
                      if(Share_r){
                        builder=build_HMM_matrix(n,(rho_[1]),beta,Pop = Pop,L=L[1],Beta=Beta,scale=window_scaling,sigma = sigma,Sigma = Self)
                        Q=builder[[1]]
                        Q=t(Q)
                        A=as.vector(Q)
                        keep=which(A>0)
                        A=A[keep]
                        Big_Xi=as.vector(Big_Xi)
                        Big_Xi=Big_Xi[keep]
                        Tc=builder[[3]]
                        g=matrix(0,nrow=length(Tc),ncol=3)
                        g[,2]=1-exp(-mu*2*Tc)
                        g[,1]=exp(-mu*2*Tc)
                        g[,3]=1
                        x=as.vector(g)
                        keep=which(x>0)
                        x=x[keep]
                        m=as.vector(Big_M)
                        m=m[keep]
                        q_=get('q_', envir=test.env)
                        nu=builder[[2]]
                        if(BW){
                          LH=LH-sum(log(A)*Big_Xi)-sum(log(x)*m)-sum(log(nu)*q_)
                        }
                        if(!BW){
                          LH=LH-sum(log(A)*Big_Xi)
                        }
                      }else{
                        for( chr in 1:NC){
                          builder=build_HMM_matrix(n,(rho_[chr]),beta,Pop = Pop,L=L[chr],Beta=Beta,scale=window_scaling,sigma = sigma,Sigma = Self)
                          Q=builder[[1]]
                          Q=t(Q)
                          A=as.vector(Q)
                          keep=which(A>0)
                          A=A[keep]
                          Big_Xi[[chr]]=as.vector(Big_Xi[[chr]])
                          Big_Xi[[chr]]=Big_Xi[[chr]][keep]
                          Tc=builder[[3]]
                          g=matrix(0,nrow=length(Tc),ncol=3)
                          g[,2]=1-exp(-mu*2*Tc)
                          g[,1]=exp(-mu*2*Tc)
                          g[,3]=1
                          x=as.vector(g)
                          keep=which(x>0)
                          x=x[keep]
                          m=as.vector(Big_M[[chr]])
                          m=m[keep]
                          q_=get('q_', envir=test.env)
                          nu=builder[[2]]
                          if(BW){
                            LH=LH-sum(log(A)*Big_Xi[[chr]])-sum(log(x)*m)-sum(log(nu)*q_[[chr]])
                          }
                          if(!BW){
                            LH=LH-sum(log(A)*Big_Xi[[chr]])
                          }

                        }
                      }

                      return(LH)
                    }
                    sol= BB::BBoptim(c(oldrho,oldbeta,oldXi_),function_to_minimize_optim,lower=0,upper=1,method=c(2),control = list(maxit=30,M=c(20)))
                    LH=as.numeric(as.matrix(sol[[2]]))
                    sol=as.matrix(sol[[1]])
                    sol=as.numeric(sol[1:(1+length(oldrho)+(Klink)),1])
                    rho=sol[1:length(oldrho)]
                    beta_=sol[1+length(oldrho)]
                    Xi_=sol[(2+length(oldrho)):length(sol)]
                    oldrho=rho
                    oldbeta=beta_
                    oldXi_=Xi_

                  }
                }
              }

              if(!SB){
                if(SF){
                  if(Popfix){
                    function_to_minimize <-function(param){
                      Boxr=get('Boxr', envir=test.env)
                      mu=get('mu', envir=test.env)
                      NC=get('NC', envir=test.env)
                      lr=get('lr', envir=test.env)
                      rho_=param[1:lr]
                      rho_=rho_*sum(Boxr)
                      rho_=rho_-(Boxr[1])
                      rho_=10^(rho_)
                      Rho=get('Rho', envir=test.env)
                      rho_=rho_*Rho
                      beta=get('beta', envir=test.env)
                      L=get('L', envir=test.env)
                      n=get('k', envir=test.env)
                      Big_Xi=get('Big_Xi', envir=test.env)
                      Beta=get('Beta', envir=test.env)
                      window_scaling=get('window_scaling', envir=test.env)
                      Boxs=get('Boxs', envir=test.env)
                      Self=get('Self', envir=test.env)
                      Big_M=get('Big_M', envir=test.env)
                      sigma=param[1+lr]
                      sigma=sigma*(Boxs[2]-Boxs[1])
                      sigma=sigma+Boxs[1]
                      sigma=min(sigma,0.99)
                      window_scaling=get('window_scaling', envir=test.env)
                      BW=get('BW', envir=test.env)
                      Share_r=get('Share_r', envir=test.env)
                      Pop=get('Pop', envir=test.env)

                      LH=0
                      if(Share_r){
                        builder=build_HMM_matrix(n,(rho_[1]),beta,Pop = Pop,L=L[1],Beta=Beta,scale=window_scaling,sigma = sigma,Sigma = Self)
                        Q=builder[[1]]
                        Q=t(Q)
                        A=as.vector(Q)
                        keep=which(A>0)
                        A=A[keep]
                        Big_Xi=as.vector(Big_Xi)
                        Big_Xi=Big_Xi[keep]
                        Tc=builder[[3]]
                        g=matrix(0,nrow=length(Tc),ncol=3)
                        g[,2]=1-exp(-mu*2*Tc)
                        g[,1]=exp(-mu*2*Tc)
                        g[,3]=1
                        x=as.vector(g)
                        keep=which(x>0)
                        x=x[keep]
                        m=as.vector(Big_M)
                        m=m[keep]
                        q_=get('q_', envir=test.env)
                        nu=builder[[2]]
                        if(BW){
                          LH=LH-sum(log(A)*Big_Xi)-sum(log(x)*m)-sum(log(nu)*q_)
                        }
                        if(!BW){
                          LH=LH-sum(log(A)*Big_Xi)
                        }
                      }else{
                        for(chr in 1:NC){
                          builder=build_HMM_matrix(n,(rho_[chr]),beta,Pop = Pop,L=L[chr],Beta=Beta,scale=window_scaling,sigma = sigma,Sigma = Self)
                          Q=builder[[1]]
                          Q=t(Q)
                          A=as.vector(Q)
                          keep=which(A>0)
                          A=A[keep]
                          Big_Xi[[chr]]=as.vector(Big_Xi[[chr]])
                          Big_Xi[[chr]]=Big_Xi[[chr]][keep]
                          Tc=builder[[3]]
                          g=matrix(0,nrow=length(Tc),ncol=3)
                          g[,2]=1-exp(-mu[chr]*2*Tc)
                          g[,1]=exp(-mu[chr]*2*Tc)
                          g[,3]=1
                          x=as.vector(g)
                          keep=which(x>0)
                          x=x[keep]
                          m=as.vector(Big_M[[chr]])
                          m=m[keep]
                          q_=get('q_', envir=test.env)
                          nu=builder[[2]]
                          if(BW){
                            LH=LH-sum(log(A)*Big_Xi[[chr]])-sum(log(x)*m)-sum(log(nu)*q_[[chr]])
                          }
                          if(!BW){  LH=LH-sum(log(A)*Big_Xi[[chr]])
                          }

                        }
                      }



                      return(LH)
                    }
                    sol= BB::BBoptim(c(oldrho,oldsigma),function_to_minimize,lower=0,upper=1,method=c(2),control = list(maxit=30,M=c(20)))
                    LH=as.numeric(as.matrix(sol[[2]]))
                    sol=as.matrix(sol[[1]])
                    sol=as.numeric(sol[1:(length(oldrho)+1),1])
                    rho=sol[1:length(oldrho)]
                    sigma_=sol[length(oldrho)+1]
                    oldrho=rho
                    oldsigma=sigma_
                  }
                  if(!Popfix){
                    function_to_minimize_optim<-function(param){
                      Boxr=get('Boxr', envir=test.env)
                      mu=get('mu', envir=test.env)
                      NC=get('NC', envir=test.env)
                      lr=get('lr', envir=test.env)
                      rho_=param[1:lr]
                      rho_=rho_*sum(Boxr)
                      rho_=rho_-(Boxr[1])
                      rho_=10^(rho_)
                      Rho=get('Rho', envir=test.env)
                      rho_=rho_*Rho
                      beta=get('beta', envir=test.env)
                      BoxP=get('BoxP', envir=test.env)
                      Xi_=param[(2+lr):length(param)]
                      Xi=vector()
                      pop_vect=get('pop_vect', envir=test.env)
                      xx=0
                      for(ix in 1:length(Xi_)){
                        x=xx+1
                        xx = xx + pop_vect[ix]
                        Xi[x:xx]=Xi_[ix]
                      }
                      Xi=Xi*sum(BoxP)
                      Xi=Xi-(BoxP[1])
                      Xi=10^Xi
                      L=get('L', envir=test.env)
                      n=get('k', envir=test.env)
                      Big_Xi=get('Big_Xi', envir=test.env)
                      Beta=get('Beta', envir=test.env)
                      window_scaling=get('window_scaling', envir=test.env)
                      Boxs=get('Boxs', envir=test.env)
                      Self=get('Self', envir=test.env)
                      sigma=param[1+lr]
                      sigma=sigma*(Boxs[2]-Boxs[1])
                      sigma=sigma+Boxs[1]
                      sigma=min(sigma,0.99)
                      window_scaling=get('window_scaling', envir=test.env)
                      BW=get('BW', envir=test.env)
                      Share_r=get('Share_r', envir=test.env)
                      Pop=get('Pop', envir=test.env)
                      Big_M=get('Big_M', envir=test.env)
                      if(Share_r){
                        builder=build_HMM_matrix(n,(rho_[1]),beta,Pop = Pop,Xi=Xi,L=L[1],Beta=Beta,scale=window_scaling,sigma = sigma,Sigma = Self)
                        Q=builder[[1]]
                        Q=t(Q)
                        A=as.vector(Q)
                        keep=which(A>0)
                        A=A[keep]
                        Big_Xi=as.vector(Big_Xi)
                        Big_Xi=Big_Xi[keep]
                        Tc=builder[[3]]
                        g=matrix(0,nrow=length(Tc),ncol=3)
                        g[,2]=1-exp(-mu*2*Tc)
                        g[,1]=exp(-mu*2*Tc)
                        g[,3]=1
                        x=as.vector(g)
                        keep=which(x>0)
                        x=x[keep]
                        m=as.vector(Big_M)
                        m=m[keep]
                        q_=get('q_', envir=test.env)
                        nu=builder[[2]]
                        if(BW){  LH=LH-sum(log(A)*Big_Xi)-sum(log(x)*m)-sum(log(nu)*q_)
                        }
                        if(!BW){  LH=LH-sum(log(A)*Big_Xi)
                        }
                      }else{
                        for( chr in 1:NC){
                          builder=build_HMM_matrix(n,(rho_[chr]),beta,Pop = Pop,Xi=Xi,L=L[chr],Beta=Beta,scale=window_scaling,sigma = sigma,Sigma = Self)
                          Q=builder[[1]]
                          Q=t(Q)
                          A=as.vector(Q)
                          keep=which(A>0)
                          A=A[keep]
                          Big_Xi[[chr]]=as.vector(Big_Xi[[chr]])
                          Big_Xi[[chr]]=Big_Xi[[chr]][keep]
                          Tc=builder[[3]]
                          g=matrix(0,nrow=length(Tc),ncol=3)
                          g[,2]=1-exp(-mu*2*Tc)
                          g[,1]=exp(-mu*2*Tc)
                          g[,3]=1
                          x=as.vector(g)
                          keep=which(x>0)
                          x=x[keep]
                          m=as.vector(Big_M[[chr]])
                          m=m[keep]
                          q_=get('q_', envir=test.env)
                          nu=builder[[2]]
                          if(BW){  LH=LH-sum(log(A)*Big_Xi[[chr]])-sum(log(x)*m)-sum(log(nu)*q_[[chr]])
                          }
                          if(!BW){  LH=LH-sum(log(A)*Big_Xi[[chr]])
                          }

                        }
                      }
                      LH=0

                      return(LH)
                    }
                    sol= BB::BBoptim(c(oldrho,oldsigma,oldXi_),function_to_minimize_optim,lower=0,upper=1,method=c(2),control = list(maxit=30,M=c(20)))
                    LH=as.numeric(as.matrix(sol[[2]]))
                    sol=as.matrix(sol[[1]])
                    sol=as.numeric(sol[1:(1+length(oldrho)+(Klink)),1])
                    rho=sol[1:length(oldrho)]
                    sigma_=sol[1+length(oldrho)]
                    Xi_=sol[(2+length(oldrho)):length(sol)]
                    oldrho=rho
                    oldXi_=Xi_
                    oldsigma=sigma_

                  }
                }
                if(!SF){
                  if(Popfix){
                    function_to_minimize <-function(param){
                      Boxr=get('Boxr', envir=test.env)
                      mu=get('mu', envir=test.env)
                      NC=get('NC', envir=test.env)
                      lr=get('lr', envir=test.env)
                      rho_=param[1:lr]
                      rho_=rho_*sum(Boxr)
                      rho_=rho_-(Boxr[1])
                      rho_=10^(rho_)
                      Rho=get('Rho', envir=test.env)
                      rho_=rho_*Rho
                      beta=get('beta', envir=test.env)
                      L=get('L', envir=test.env)
                      n=get('k', envir=test.env)
                      Big_Xi=get('Big_Xi', envir=test.env)
                      Beta=get('Beta', envir=test.env)
                      window_scaling=get('window_scaling', envir=test.env)
                      BW=get('BW', envir=test.env)
                      Share_r=get('Share_r', envir=test.env)
                      Pop=get('Pop', envir=test.env)
                      Big_M=get('Big_M', envir=test.env)
                      LH=0
                      Self=get('Self', envir=test.env)
                      sigma=get('sigma', envir=test.env)
                      if(Share_r){
                        builder=build_HMM_matrix(n,(rho_[1]),beta,Pop = Pop,Xi=Xi,L=L[1],Beta=Beta,scale=window_scaling,sigma = sigma,Sigma = Self)
                        Q=builder[[1]]
                        Q=t(Q)
                        A=as.vector(Q)
                        keep=which(A>0)
                        A=A[keep]
                        Big_Xi=as.vector(Big_Xi)
                        Big_Xi=Big_Xi[keep]
                        Tc=builder[[3]]
                        g=matrix(0,nrow=length(Tc),ncol=3)
                        g[,2]=1-exp(-mu*2*Tc)
                        g[,1]=exp(-mu*2*Tc)
                        g[,3]=1
                        x=as.vector(g)
                        keep=which(x>0)
                        x=x[keep]
                        m=as.vector(Big_M)
                        m=m[keep]
                        q_=get('q_', envir=test.env)
                        nu=builder[[2]]
                        if(BW){
                          LH=LH-sum(log(A)*Big_Xi)-sum(log(x)*m)-sum(log(nu)*q_)
                        }
                        if(!BW){
                          LH=LH-sum(log(A)*Big_Xi)
                        }
                      }else{
                        for( chr in 1:NC){
                          builder=build_HMM_matrix(n,(rho_[chr]),beta,Pop = Pop,Xi=Xi,L=L[chr],Beta=Beta,scale=window_scaling,sigma = sigma,Sigma = Self)
                          Q=builder[[1]]
                          Q=t(Q)
                          A=as.vector(Q)
                          keep=which(A>0)
                          A=A[keep]
                          Big_Xi[[chr]]=as.vector(Big_Xi[[chr]])
                          Big_Xi[[chr]]=Big_Xi[[chr]][keep]
                          Tc=builder[[3]]
                          g=matrix(0,nrow=length(Tc),ncol=3)
                          g[,2]=1-exp(-mu*2*Tc)
                          g[,1]=exp(-mu*2*Tc)
                          g[,3]=1
                          x=as.vector(g)
                          keep=which(x>0)
                          x=x[keep]
                          m=as.vector(Big_M[[chr]])
                          m=m[keep]
                          q_=get('q_', envir=test.env)
                          nu=builder[[2]]
                          if(BW){
                            LH=LH-sum(log(A)*Big_Xi[[chr]])-sum(log(x)*m)-sum(log(nu)*q_[[chr]])
                          }
                          if(!BW){
                            LH=LH-sum(log(A)*Big_Xi[[chr]])
                          }

                        }
                      }

                      return(LH)
                    }
                    sol= BB::BBoptim(c(oldrho),function_to_minimize,lower=0,upper=1,method=c(2),control = list(maxit=30,M=c(20)))
                    LH=as.numeric(as.matrix(sol[[2]]))
                    sol=as.matrix(sol[[1]])
                    sol=as.numeric(sol[1:(length(oldrho)),1])
                    rho=sol[1:length(oldrho)]
                    oldrho=rho
                  }
                  if(!Popfix){
                    function_to_minimize_optim<-function(param){
                      Boxr=get('Boxr', envir=test.env)
                      mu=get('mu', envir=test.env)
                      NC=get('NC', envir=test.env)
                      lr=get('lr', envir=test.env)
                      rho_=param[1:lr]
                      rho_=rho_*sum(Boxr)
                      rho_=rho_-(Boxr[1])
                      rho_=10^(rho_)
                      Rho=get('Rho', envir=test.env)
                      rho_=rho_*Rho
                      beta=get('beta', envir=test.env)
                      BoxP=get('BoxP', envir=test.env)
                      Xi_=param[(1+lr):length(param)]
                      Xi=vector()
                      pop_vect=get('pop_vect', envir=test.env)
                      xx=0
                      for(ix in 1:length(Xi_)){
                        x=xx+1
                        xx = xx + pop_vect[ix]
                        Xi[x:xx]=Xi_[ix]
                      }
                      Xi=Xi*sum(BoxP)
                      Xi=Xi-(BoxP[1])
                      Xi=10^Xi
                      L=get('L', envir=test.env)
                      n=get('k', envir=test.env)
                      Big_Xi=get('Big_Xi', envir=test.env)
                      Beta=get('Beta', envir=test.env)
                      window_scaling=get('window_scaling', envir=test.env)
                      BW=get('BW', envir=test.env)
                      Share_r=get('Share_r', envir=test.env)
                      Pop=get('Pop', envir=test.env)
                      Big_M=get('Big_M', envir=test.env)
                      LH=0
                      Self=get('Self', envir=test.env)
                      sigma=get('sigma', envir=test.env)
                      if(Share_r){
                        builder=build_HMM_matrix(n,(rho_[1]),beta,Pop = Pop,Xi=Xi,L=L[1],Beta=Beta,scale=window_scaling,sigma = sigma,Sigma = Self)
                        Q=builder[[1]]
                        Q=t(Q)
                        A=as.vector(Q)
                        keep=which(A>0)
                        A=A[keep]
                        Big_Xi=as.vector(Big_Xi)
                        Big_Xi=Big_Xi[keep]
                        Tc=builder[[3]]
                        g=matrix(0,nrow=length(Tc),ncol=3)
                        g[,2]=1-exp(-mu*2*Tc)
                        g[,1]=exp(-mu*2*Tc)
                        g[,3]=1
                        x=as.vector(g)
                        keep=which(x>0)
                        x=x[keep]
                        m=as.vector(Big_M)
                        m=m[keep]
                        q_=get('q_', envir=test.env)
                        nu=builder[[2]]
                        if(BW){
                          LH=LH-sum(log(A)*Big_Xi)-sum(log(x)*m)-sum(log(nu)*q_)
                        }
                        if(!BW){
                          LH=LH-sum(log(A)*Big_Xi)
                        }
                      }else{
                        for( chr in 1:NC){
                          builder=build_HMM_matrix(n,(rho_[chr]),beta,Pop = Pop,Xi=Xi,L=L[chr],Beta=Beta,scale=window_scaling,sigma = sigma,Sigma = Self)
                          Q=builder[[1]]
                          Q=t(Q)
                          A=as.vector(Q)
                          keep=which(A>0)
                          A=A[keep]
                          Big_Xi[[chr]]=as.vector(Big_Xi[[chr]])
                          Big_Xi[[chr]]=Big_Xi[[chr]][keep]
                          Tc=builder[[3]]
                          g=matrix(0,nrow=length(Tc),ncol=3)
                          g[,2]=1-exp(-mu*2*Tc)
                          g[,1]=exp(-mu*2*Tc)
                          g[,3]=1
                          x=as.vector(g)
                          keep=which(x>0)
                          x=x[keep]
                          m=as.vector(Big_M[[chr]])
                          m=m[keep]
                          q_=get('q_', envir=test.env)
                          nu=builder[[2]]
                          if(BW){
                            LH=LH-sum(log(A)*Big_Xi[[chr]])-sum(log(x)*m)-sum(log(nu)*q_[[chr]])
                          }
                          if(!BW){
                            LH=LH-sum(log(A)*Big_Xi[[chr]])
                          }

                        }
                      }

                      return(LH)
                    }
                    sol= BB::BBoptim(c(oldrho,oldXi_),function_to_minimize_optim,lower=0,upper=1,method=c(2),control = list(maxit=30,M=c(20)))
                    LH=as.numeric(as.matrix(sol[[2]]))
                    sol=as.matrix(sol[[1]])
                    sol=as.numeric(sol[1:(length(oldrho)+(Klink)),1])
                    rho=sol[1:length(oldrho)]
                    Xi_=sol[(1+length(oldrho)):length(sol)]
                    oldrho=rho
                    oldXi_=Xi_

                  }
                }
              }
            }
            if(!ER){
              if(SB){
                if(SF){
                  if(Popfix){
                    function_to_minimize <-function(param){
                      Boxr=get('Boxr', envir=test.env)
                      mu=get('mu', envir=test.env)
                      Rho=get('Rho', envir=test.env)
                      NC=get('NC', envir=test.env)
                      rho_=Rho
                      BoxB=get('BoxB', envir=test.env)
                      beta=((param[1]*(BoxB[2]-BoxB[1]))+BoxB[1])^2
                      L=get('L', envir=test.env)
                      n=get('k', envir=test.env)
                      Big_Xi=get('Big_Xi', envir=test.env)
                      Big_M=get('Big_M', envir=test.env)
                      Beta=get('Beta', envir=test.env)
                      Boxs=get('Boxs', envir=test.env)
                      Self=get('Self', envir=test.env)
                      sigma=param[2]
                      sigma=sigma*(Boxs[2]-Boxs[1])
                      sigma=sigma+Boxs[1]
                      sigma=min(sigma,0.99)
                      window_scaling=get('window_scaling', envir=test.env)
                      BW=get('BW', envir=test.env)
                      Share_r=get('Share_r', envir=test.env)
                      Pop=get('Pop', envir=test.env)
                      LH=0
                      if(Share_r){
                        builder=build_HMM_matrix(n,(rho_[1]),beta,Pop = Pop,L=L[1],Beta=Beta,scale=window_scaling,sigma = sigma,Sigma = Self)
                        Q=builder[[1]]
                        Q=t(Q)
                        A=as.vector(Q)
                        keep=which(A>0)
                        A=A[keep]
                        Big_Xi=as.vector(Big_Xi)
                        Big_Xi=Big_Xi[keep]
                        Tc=builder[[3]]
                        g=matrix(0,nrow=length(Tc),ncol=3)
                        g[,2]=1-exp(-mu*2*Tc)
                        g[,1]=exp(-mu*2*Tc)
                        g[,3]=1
                        x=as.vector(g)
                        keep=which(x>0)
                        x=x[keep]
                        m=as.vector(Big_M)
                        m=m[keep]
                        q_=get('q_', envir=test.env)
                        nu=builder[[2]]
                        if(BW){
                          LH=LH-sum(log(A)*Big_Xi)-sum(log(x)*m)-sum(log(nu)*q_)
                        }
                        if(!BW){
                          LH=LH-sum(log(A)*Big_Xi)
                        }
                      }else{
                        for(chr in 1:NC){
                          builder=build_HMM_matrix(n,(rho_[chr]),beta,Pop = Pop,L=L[chr],Beta=Beta,scale=window_scaling,sigma = sigma,Sigma = Self)
                          Q=builder[[1]]
                          Q=t(Q)
                          A=as.vector(Q)
                          keep=which(A>0)
                          A=A[keep]
                          Big_Xi[[chr]]=as.vector(Big_Xi[[chr]])
                          Big_Xi[[chr]]=Big_Xi[[chr]][keep]
                          Tc=builder[[3]]
                          g=matrix(0,nrow=length(Tc),ncol=3)
                          g[,2]=1-exp(-mu[chr]*2*Tc)
                          g[,1]=exp(-mu[chr]*2*Tc)
                          g[,3]=1
                          x=as.vector(g)
                          keep=which(x>0)
                          x=x[keep]
                          m=as.vector(Big_M[[chr]])
                          m=m[keep]
                          q_=get('q_', envir=test.env)
                          nu=builder[[2]]
                          if(BW){
                            LH=LH-sum(log(A)*Big_Xi[[chr]])-sum(log(x)*m)-sum(log(nu)*q_[[chr]])
                          }
                          if(!BW){
                            LH=LH-sum(log(A)*Big_Xi[[chr]])
                          }

                        }
                      }

                      return(LH)
                    }
                    sol= BB::BBoptim(c(oldbeta,oldsigma),function_to_minimize,lower=0,upper=1,method=c(2),control = list(maxit=30,M=c(20)))
                    LH=as.numeric(as.matrix(sol[[2]]))
                    sol=as.matrix(sol[[1]])
                    sol=as.numeric(sol[1:2,1])
                    beta_=sol[1]
                    sigma_=sol[2]
                    oldbeta=sol[1]
                    oldsigma=sol[2]
                  }
                  if(!Popfix){
                    function_to_minimize_optim<-function(param){
                      Boxr=get('Boxr', envir=test.env)
                      mu=get('mu', envir=test.env)
                      Rho=get('Rho', envir=test.env)
                      NC=get('NC',envir = test.env)
                      rho_=Rho
                      BoxB=get('BoxB', envir=test.env)
                      Boxs=get('Boxs', envir=test.env)
                      beta=((param[1]*(BoxB[2]-BoxB[1]))+BoxB[1])^2
                      BoxP=get('BoxP', envir=test.env)
                      sigma=param[2]
                      sigma=sigma*(Boxs[2]-Boxs[1])
                      sigma=sigma+Boxs[1]
                      sigma=min(sigma,0.99)
                      Xi_=param[3:length(param)]
                      Xi=vector()
                      pop_vect=get('pop_vect', envir=test.env)
                      xx=0
                      for(ix in 1:length(Xi_)){
                        x=xx+1
                        xx = xx + pop_vect[ix]
                        Xi[x:xx]=Xi_[ix]
                      }
                      Xi=Xi*sum(BoxP)
                      Xi=Xi-(BoxP[1])
                      Xi=10^Xi
                      L=get('L', envir=test.env)
                      n=get('k', envir=test.env)
                      Big_Xi=get('Big_Xi', envir=test.env)
                      Beta=get('Beta', envir=test.env)
                      Self=get('Self', envir=test.env)
                      window_scaling=get('window_scaling', envir=test.env)
                      BW=get('BW', envir=test.env)
                      Share_r=get('Share_r', envir=test.env)
                      Pop=get('Pop', envir=test.env)
                      LH=0
                      Big_M=get('Big_M', envir=test.env)
                      if(Share_r){
                        builder=build_HMM_matrix(n,(rho_[1]),beta,Pop = Pop,Xi=Xi,L=L[1],Beta=Beta,scale=window_scaling,sigma = sigma,Sigma = Self)
                        Q=builder[[1]]
                        Q=t(Q)
                        A=as.vector(Q)
                        keep=which(A>0)
                        A=A[keep]
                        Big_Xi=as.vector(Big_Xi)
                        Big_Xi=Big_Xi[keep]
                        Tc=builder[[3]]
                        g=matrix(0,nrow=length(Tc),ncol=3)
                        g[,2]=1-exp(-mu*2*Tc)
                        g[,1]=exp(-mu*2*Tc)
                        g[,3]=1
                        x=as.vector(g)
                        keep=which(x>0)
                        x=x[keep]
                        m=as.vector(Big_M)
                        m=m[keep]
                        q_=get('q_', envir=test.env)
                        nu=builder[[2]]
                        if(BW){
                          LH=LH-sum(log(A)*Big_Xi)-sum(log(x)*m)-sum(log(nu)*q_)
                        }
                        if(!BW){
                          LH=LH-sum(log(A)*Big_Xi)
                        }
                      }else{
                        for(chr in 1:NC){
                          builder=build_HMM_matrix(n,(rho_[chr]),beta,Pop = Pop,Xi=Xi,L=L[chr],Beta=Beta,scale=window_scaling,sigma = sigma,Sigma = Self)
                          Q=builder[[1]]
                          Q=t(Q)
                          A=as.vector(Q)
                          keep=which(A>0)
                          A=A[keep]
                          Big_Xi[[chr]]=as.vector(Big_Xi[[chr]])
                          Big_Xi[[chr]]=Big_Xi[[chr]][keep]
                          Tc=builder[[3]]
                          g=matrix(0,nrow=length(Tc),ncol=3)
                          g[,2]=1-exp(-mu[chr]*2*Tc)
                          g[,1]=exp(-mu[chr]*2*Tc)
                          g[,3]=1
                          x=as.vector(g)
                          keep=which(x>0)
                          x=x[keep]
                          m=as.vector(Big_M[[chr]])
                          m=m[keep]
                          q_=get('q_', envir=test.env)
                          nu=builder[[2]]
                          if(BW){
                            LH=LH-sum(log(A)*Big_Xi[[chr]])-sum(log(x)*m)-sum(log(nu)*q_[[chr]])
                          }
                          if(!BW){
                            LH=LH-sum(log(A)*Big_Xi[[chr]])
                          }

                        }
                      }

                      return(LH)
                    }
                    sol= BB::BBoptim(c(oldbeta,oldsigma,oldXi_),function_to_minimize_optim,lower=0,upper=1,method=c(2),control = list(maxit=30,M=c(20)))
                    LH=as.numeric(as.matrix(sol[[2]]))
                    sol=as.matrix(sol[[1]])
                    sol=as.numeric(sol[1:(2+(Klink)),1])
                    beta_=sol[1]
                    sigma_=sol[2]
                    Xi_=sol[3:length(sol)]
                    oldbeta=beta_
                    oldXi_=Xi_
                    oldsigma=sigma_

                  }
                }
                if(!SF){
                  if(Popfix){
                    function_to_minimize <-function(param){
                      Boxr=get('Boxr', envir=test.env)
                      mu=get('mu', envir=test.env)
                      NC=get('NC',envir = test.env)
                      Rho=get('Rho', envir=test.env)
                      rho_=Rho
                      BoxB=get('BoxB', envir=test.env)
                      beta=((param[1]*(BoxB[2]-BoxB[1]))+BoxB[1])^2
                      L=get('L', envir=test.env)
                      n=get('k', envir=test.env)
                      Big_Xi=get('Big_Xi', envir=test.env)
                      Big_M=get('Big_M', envir=test.env)
                      M=get('M', envir=test.env)
                      Beta=get('Beta', envir=test.env)
                      window_scaling=get('window_scaling', envir=test.env)
                      BW=get('BW', envir=test.env)
                      Share_r=get('Share_r', envir=test.env)
                      Pop=get('Pop', envir=test.env)
                      LH=0
                      Self=get('Self', envir=test.env)
                      sigma=get('sigma', envir=test.env)
                      if(Share_r){
                        builder=build_HMM_matrix(n,(rho_[1]),beta,Pop = Pop,L=L[1],Beta=Beta,scale=window_scaling,sigma = sigma,Sigma = Self)
                        Q=builder[[1]]
                        Q=t(Q)
                        A=as.vector(Q)
                        keep=which(A>0)
                        A=A[keep]
                        Big_Xi=as.vector(Big_Xi)
                        Big_Xi=Big_Xi[keep]
                        Tc=builder[[3]]
                        g=matrix(0,nrow=length(Tc),ncol=3)
                        g[,2]=1-exp(-mu*2*Tc)
                        g[,1]=exp(-mu*2*Tc)
                        g[,3]=1
                        x=as.vector(g)
                        keep=which(x>0)
                        x=x[keep]
                        m=as.vector(Big_M)
                        m=m[keep]
                        q_=get('q_', envir=test.env)
                        nu=builder[[2]]
                        if(BW){
                          LH=LH-sum(log(A)*Big_Xi)-sum(log(x)*m)-sum(log(nu)*q_)
                        }
                        if(!BW){
                          LH=LH-sum(log(A)*Big_Xi)
                        }
                      }else{
                        for(chr in 1:NC){
                          builder=build_HMM_matrix(n,(rho_[chr]),beta,Pop = Pop,L=L[chr],Beta=Beta,scale=window_scaling,sigma = sigma,Sigma = Self)
                          Q=builder[[1]]
                          Q=t(Q)
                          A=as.vector(Q)
                          keep=which(A>0)
                          A=A[keep]
                          Big_Xi[[chr]]=as.vector(Big_Xi[[chr]])
                          Big_Xi[[chr]]=Big_Xi[[chr]][keep]
                          Tc=builder[[3]]
                          g=matrix(0,nrow=length(Tc),ncol=3)
                          g[,2]=1-exp(-mu[chr]*2*Tc)
                          g[,1]=exp(-mu[chr]*2*Tc)
                          g[,3]=1
                          x=as.vector(g)
                          keep=which(x>0)
                          x=x[keep]
                          m=as.vector(Big_M[[chr]])
                          m=m[keep]
                          q_=get('q_', envir=test.env)
                          nu=builder[[2]]
                          if(BW){
                            LH=LH-sum(log(A)*Big_Xi[[chr]])-sum(log(x)*m)-sum(log(nu)*q_[[chr]])
                          }
                          if(!BW){
                            LH=LH-sum(log(A)*Big_Xi[[chr]])
                          }

                        }
                      }

                      return(LH)
                    }
                    sol= BB::BBoptim(c(oldbeta),function_to_minimize,lower=0,upper=1,method=c(2),control = list(maxit=30,M=c(20)))
                    LH=as.numeric(as.matrix(sol[[2]]))
                    sol=as.matrix(sol[[1]])
                    sol=as.numeric(sol[1,1])
                    beta_=sol[1]
                    oldbeta=beta_
                  }
                  if(!Popfix){
                    function_to_minimize_optim<-function(param){
                      mu=get('mu', envir=test.env)
                      Rho=get('Rho', envir=test.env)
                      NC=get('NC',envir = test.env)
                      rho_=Rho
                      BoxB=get('BoxB', envir=test.env)
                      beta=((param[1]*(BoxB[2]-BoxB[1]))+BoxB[1])^2
                      BoxP=get('BoxP', envir=test.env)
                      Xi_=param[2:length(param)]
                      Xi=vector()
                      pop_vect=get('pop_vect', envir=test.env)
                      xx=0
                      for(ix in 1:length(Xi_)){
                        x=xx+1
                        xx = xx + pop_vect[ix]
                        Xi[x:xx]=Xi_[ix]
                      }
                      Xi=Xi*sum(BoxP)
                      Xi=Xi-(BoxP[1])
                      Xi=10^Xi
                      L=get('L', envir=test.env)
                      n=get('k', envir=test.env)
                      Big_Xi=get('Big_Xi', envir=test.env)
                      Beta=get('Beta', envir=test.env)
                      window_scaling=get('window_scaling', envir=test.env)
                      BW=get('BW', envir=test.env)
                      Share_r=get('Share_r', envir=test.env)
                      Pop=get('Pop', envir=test.env)
                      LH=0
                      Big_M=get('Big_M', envir=test.env)
                      Self=get('Self', envir=test.env)
                      sigma=get('sigma', envir=test.env)
                      if(Share_r){
                        builder=build_HMM_matrix(n,(rho_[1]),beta,Pop = Pop,Xi=Xi,L=L[1],Beta=Beta,scale=window_scaling,sigma = sigma,Sigma = Self)
                        Q=builder[[1]]
                        Q=t(Q)
                        A=as.vector(Q)
                        keep=which(A>0)
                        A=A[keep]
                        Big_Xi=as.vector(Big_Xi)
                        Big_Xi=Big_Xi[keep]
                        Tc=builder[[3]]
                        g=matrix(0,nrow=length(Tc),ncol=3)
                        g[,2]=1-exp(-mu*2*Tc)
                        g[,1]=exp(-mu*2*Tc)
                        g[,3]=1
                        x=as.vector(g)
                        keep=which(x>0)
                        x=x[keep]
                        m=as.vector(Big_M)
                        m=m[keep]
                        q_=get('q_', envir=test.env)
                        nu=builder[[2]]
                        if(BW){
                          LH=LH-sum(log(A)*Big_Xi)-sum(log(x)*m)-sum(log(nu)*q_)
                        }
                        if(!BW){
                          LH=LH-sum(log(A)*Big_Xi)
                        }
                      }else{
                        for(chr in 1:NC){
                          builder=build_HMM_matrix(n,(rho_[chr]),beta,Pop = Pop,Xi=Xi,L=L[chr],Beta=Beta,scale=window_scaling,sigma = sigma,Sigma = Self)
                          Q=builder[[1]]
                          Q=t(Q)
                          A=as.vector(Q)
                          keep=which(A>0)
                          A=A[keep]
                          Big_Xi[[chr]]=as.vector(Big_Xi[[chr]])
                          Big_Xi[[chr]]=Big_Xi[[chr]][keep]
                          Tc=builder[[3]]
                          g=matrix(0,nrow=length(Tc),ncol=3)
                          g[,2]=1-exp(-mu[chr]*2*Tc)
                          g[,1]=exp(-mu[chr]*2*Tc)
                          g[,3]=1
                          x=as.vector(g)
                          keep=which(x>0)
                          x=x[keep]
                          m=as.vector(Big_M[[chr]])
                          m=m[keep]
                          q_=get('q_', envir=test.env)
                          nu=builder[[2]]
                          if(BW){
                            LH=LH-sum(log(A)*Big_Xi[[chr]])-sum(log(x)*m)-sum(log(nu)*q_[[chr]])
                          }
                          if(!BW){
                            LH=LH-sum(log(A)*Big_Xi[[chr]])
                          }
                        }
                      }
                      return(LH)
                    }
                    sol= BB::BBoptim(c(oldbeta,oldXi_),function_to_minimize_optim,lower=0,upper=1,method=c(2),control = list(maxit=30,M=c(20)))
                    LH=as.numeric(as.matrix(sol[[2]]))
                    sol=as.matrix(sol[[1]])
                    sol=as.numeric(sol[1:(1+(Klink)),1])
                    beta_=sol[1]
                    Xi_=sol[2:length(sol)]
                    oldbeta=beta_
                    oldXi_=Xi_

                  }
                }
              }
              if(!SB){
                if(SF){
                  if(Popfix){
                    function_to_minimize <-function(param){
                      Boxr=get('Boxr', envir=test.env)
                      mu=get('mu', envir=test.env)
                      NC=get('NC',envir=test.env)
                      Rho=get('Rho', envir=test.env)
                      rho_=Rho
                      beta=get('beta', envir=test.env)
                      L=get('L', envir=test.env)
                      n=get('k', envir=test.env)
                      Big_Xi=get('Big_Xi', envir=test.env)
                      Big_M=get('Big_M', envir=test.env)
                      Beta=get('Beta', envir=test.env)
                      window_scaling=get('window_scaling', envir=test.env)
                      Boxs=get('Boxs', envir=test.env)
                      Self=get('Self', envir=test.env)
                      sigma=param[1]
                      sigma=sigma*(Boxs[2]-Boxs[1])
                      sigma=sigma+Boxs[1]
                      sigma=min(sigma,0.99)
                      window_scaling=get('window_scaling', envir=test.env)
                      BW=get('BW', envir=test.env)
                      Share_r=get('Share_r', envir=test.env)
                      Pop=get('Pop', envir=test.env)
                      LH=0
                      if(Share_r){
                        builder=build_HMM_matrix(n,(rho_[1]),beta,Pop = Pop,L=L[1],Beta=Beta,scale=window_scaling,sigma = sigma,Sigma = Self)
                        Q=builder[[1]]
                        Q=t(Q)
                        A=as.vector(Q)
                        keep=which(A>0)
                        A=A[keep]
                        Big_Xi=as.vector(Big_Xi)
                        Big_Xi=Big_Xi[keep]
                        Tc=builder[[3]]
                        g=matrix(0,nrow=length(Tc),ncol=3)
                        g[,2]=1-exp(-mu*2*Tc)
                        g[,1]=exp(-mu*2*Tc)
                        g[,3]=1
                        x=as.vector(g)
                        keep=which(x>0)
                        x=x[keep]
                        m=as.vector(Big_M)
                        m=m[keep]
                        q_=get('q_', envir=test.env)
                        nu=builder[[2]]
                        if(BW){
                          LH=LH-sum(log(A)*Big_Xi)-sum(log(x)*m)-sum(log(nu)*q_)
                        }
                        if(!BW){
                          LH=LH-sum(log(A)*Big_Xi)
                        }
                      }else{
                        for(chr in 1:NC){
                          builder=build_HMM_matrix(n,(rho_[chr]),beta,Pop = Pop,L=L[chr],Beta=Beta,scale=window_scaling,sigma = sigma,Sigma = Self)
                          Q=builder[[1]]
                          Q=t(Q)
                          A=as.vector(Q)
                          keep=which(A>0)
                          A=A[keep]
                          Big_Xi[[chr]]=as.vector(Big_Xi[[chr]])
                          Big_Xi[[chr]]=Big_Xi[[chr]][keep]
                          Tc=builder[[3]]
                          g=matrix(0,nrow=length(Tc),ncol=3)
                          g[,2]=1-exp(-mu[chr]*2*Tc)
                          g[,1]=exp(-mu[chr]*2*Tc)
                          g[,3]=1
                          x=as.vector(g)
                          keep=which(x>0)
                          x=x[keep]
                          m=as.vector(Big_M[[chr]])
                          m=m[keep]
                          q_=get('q_', envir=test.env)
                          nu=builder[[2]]
                          if(BW){
                            LH=LH-sum(log(A)*Big_Xi[[chr]])-sum(log(x)*m)-sum(log(nu)*q_[[chr]])
                          }
                          if(!BW){
                            LH=LH-sum(log(A)*Big_Xi[[chr]])
                          }

                        }
                      }

                      return(LH)
                    }
                    sol= BB::BBoptim(c(oldsigma),function_to_minimize_optim,lower=0,upper=1,method=c(2),control = list(maxit=30,M=c(20)))
                    LH=as.numeric(as.matrix(sol[[2]]))
                    sol=as.matrix(sol[[1]])
                    sol=as.numeric(sol[1,1])
                    sigma_=sol[1]
                    oldsigma=sigma_
                  }
                  if(!Popfix){
                    function_to_minimize_optim<-function(param){
                      Boxr=get('Boxr', envir=test.env)
                      Rho=get('Rho', envir=test.env)
                      mu=get('mu', envir=test.env)
                      NC=get('NC',envir = test.env)
                      rho_=Rho
                      beta=get('beta', envir=test.env)
                      BoxP=get('BoxP', envir=test.env)
                      Xi_=param[2:length(param)]
                      Xi=vector()
                      pop_vect=get('pop_vect', envir=test.env)
                      xx=0
                      for(ix in 1:length(Xi_)){
                        x=xx+1
                        xx = xx + pop_vect[ix]
                        Xi[x:xx]=Xi_[ix]
                      }
                      Xi=Xi*sum(BoxP)
                      Xi=Xi-(BoxP[1])
                      Xi=10^Xi
                      L=get('L', envir=test.env)
                      n=get('k', envir=test.env)
                      Big_Xi=get('Big_Xi', envir=test.env)
                      Beta=get('Beta', envir=test.env)
                      window_scaling=get('window_scaling', envir=test.env)
                      Boxs=get('Boxs', envir=test.env)
                      Self=get('Self', envir=test.env)
                      sigma=param[1]
                      sigma=sigma*(Boxs[2]-Boxs[1])
                      sigma=sigma+Boxs[1]
                      sigma=min(sigma,0.99)
                      window_scaling=get('window_scaling', envir=test.env)
                      BW=get('BW', envir=test.env)
                      Share_r=get('Share_r', envir=test.env)
                      Pop=get('Pop', envir=test.env)
                      LH=0
                      Big_M=get('Big_M', envir=test.env)
                      if(Share_r){
                        builder=build_HMM_matrix(n,(rho_[1]),beta,Pop = Pop,Xi=Xi,L=L[1],Beta=Beta,scale=window_scaling,sigma = sigma,Sigma = Self)
                        Q=builder[[1]]
                        Q=t(Q)
                        A=as.vector(Q)
                        keep=which(A>0)
                        A=A[keep]
                        Big_Xi=as.vector(Big_Xi)
                        Big_Xi=Big_Xi[keep]
                        Tc=builder[[3]]
                        g=matrix(0,nrow=length(Tc),ncol=3)
                        g[,2]=1-exp(-mu*2*Tc)
                        g[,1]=exp(-mu*2*Tc)
                        g[,3]=1
                        x=as.vector(g)
                        keep=which(x>0)
                        x=x[keep]
                        m=as.vector(Big_M)
                        m=m[keep]
                        q_=get('q_', envir=test.env)
                        nu=builder[[2]]
                        if(BW){
                          LH=LH-sum(log(A)*Big_Xi)-sum(log(x)*m)-sum(log(nu)*q_)
                        }
                        if(!BW){
                          LH=LH-sum(log(A)*Big_Xi)
                        }
                      }else{
                        for(chr in 1:NC){
                          builder=build_HMM_matrix(n,(rho_[chr]),beta,Pop = Pop,Xi=Xi,L=L[chr],Beta=Beta,scale=window_scaling,sigma = sigma,Sigma = Self)
                          Q=builder[[1]]
                          Q=t(Q)
                          A=as.vector(Q)
                          keep=which(A>0)
                          A=A[keep]
                          Big_Xi[[chr]]=as.vector(Big_Xi[[chr]])
                          Big_Xi[[chr]]=Big_Xi[[chr]][keep]
                          Tc=builder[[3]]
                          g=matrix(0,nrow=length(Tc),ncol=3)
                          g[,2]=1-exp(-mu[chr]*2*Tc)
                          g[,1]=exp(-mu[chr]*2*Tc)
                          g[,3]=1
                          x=as.vector(g)
                          keep=which(x>0)
                          x=x[keep]
                          m=as.vector(Big_M[[chr]])
                          m=m[keep]
                          q_=get('q_', envir=test.env)
                          nu=builder[[2]]
                          if(BW){
                            LH=LH-sum(log(A)*Big_Xi[[chr]])-sum(log(x)*m)-sum(log(nu)*q_[[chr]])
                          }
                          if(!BW){
                            LH=LH-sum(log(A)*Big_Xi[[chr]])
                          }
                        }
                      }

                      return(LH)
                    }
                    sol= BB::BBoptim(c(oldsigma,oldXi_),function_to_minimize_optim,lower=0,upper=1,method=c(2),control = list(maxit=30,M=c(20)))
                    LH=as.numeric(as.matrix(sol[[2]]))
                    sol=as.matrix(sol[[1]])
                    sol=as.numeric(sol[1:(1+(Klink)),1])
                    sigma_=sol[1]
                    Xi_=sol[2:length(sol)]
                    oldXi_=Xi_
                    oldsigma=sigma_
                    print(sigma_)

                  }
                }
                if(!SF){
                  if(!Popfix){
                    function_to_minimize_optim<-function(param){
                      Boxr=get('Boxr', envir=test.env)
                      mu=get('mu', envir=test.env)
                      Rho=get('Rho', envir=test.env)
                      NC=get('NC',envir=test.env)
                      rho_=Rho
                      beta=get('beta', envir=test.env)
                      BoxP=get('BoxP', envir=test.env)
                      Xi_=param[1:length(param)]
                      Xi=vector()
                      pop_vect=get('pop_vect', envir=test.env)
                      xx=0
                      for(ix in 1:length(Xi_)){
                        x=xx+1
                        xx = xx + pop_vect[ix]
                        Xi[x:xx]=Xi_[ix]
                      }
                      Xi=Xi*sum(BoxP)
                      Xi=Xi-(BoxP[1])
                      Xi=10^Xi
                      L=get('L', envir=test.env)
                      n=get('k', envir=test.env)
                      Big_Xi=get('Big_Xi', envir=test.env)
                      Beta=get('Beta', envir=test.env)
                      window_scaling=get('window_scaling', envir=test.env)
                      BW=get('BW', envir=test.env)
                      Share_r=get('Share_r', envir=test.env)
                      Pop=get('Pop', envir=test.env)
                      LH=0
                      Big_M=get('Big_M', envir=test.env)
                      Self=get('Self', envir=test.env)
                      sigma=get('sigma', envir=test.env)
                      if(Share_r){
                        builder=build_HMM_matrix(n,(rho_[1]),beta,Pop = Pop,Xi=Xi,L=L[1],Beta=Beta,scale=window_scaling,sigma = sigma,Sigma = Self)
                        Q=builder[[1]]
                        Q=t(Q)
                        A=as.vector(Q)
                        keep=which(A>0)
                        A=A[keep]
                        Big_Xi=as.vector(Big_Xi)
                        Big_Xi=Big_Xi[keep]
                        Tc=builder[[3]]
                        g=matrix(0,nrow=length(Tc),ncol=3)
                        g[,2]=1-exp(-mu*2*Tc)
                        g[,1]=exp(-mu*2*Tc)
                        g[,3]=1
                        x=as.vector(g)
                        keep=which(x>0)
                        x=x[keep]
                        m=as.vector(Big_M)
                        m=m[keep]
                        q_=get('q_', envir=test.env)
                        nu=builder[[2]]
                        if(BW){
                          LH=LH-sum(log(A)*Big_Xi)-sum(log(x)*m)-sum(log(nu)*q_)
                        }
                        if(!BW){
                          LH=LH-sum(log(A)*Big_Xi)
                        }
                      }else{
                        for(chr in 1:NC){
                          builder=build_HMM_matrix(n,(rho_[chr]),beta,Pop = Pop,Xi=Xi,L=L[chr],Beta=Beta,scale=window_scaling,sigma = sigma,Sigma = Self)
                          Q=builder[[1]]
                          Q=t(Q)
                          A=as.vector(Q)
                          keep=which(A>0)
                          A=A[keep]
                          Big_Xi[[chr]]=as.vector(Big_Xi[[chr]])
                          Big_Xi[[chr]]=Big_Xi[[chr]][keep]
                          Tc=builder[[3]]
                          g=matrix(0,nrow=length(Tc),ncol=3)
                          g[,2]=1-exp(-mu[chr]*2*Tc)
                          g[,1]=exp(-mu[chr]*2*Tc)
                          g[,3]=1
                          x=as.vector(g)
                          keep=which(x>0)
                          x=x[keep]
                          m=as.vector(Big_M[[chr]])
                          m=m[keep]
                          q_=get('q_', envir=test.env)
                          nu=builder[[2]]
                          if(BW){
                            LH=LH-sum(log(A)*Big_Xi[[chr]])-sum(log(x)*m)-sum(log(nu)*q_[[chr]])
                          }
                          if(!BW){
                            LH=LH-sum(log(A)*Big_Xi[[chr]])
                          }

                        }
                      }

                      return(LH)
                    }
                    sol= BB::BBoptim(c(oldXi_),function_to_minimize_optim,lower=0,upper=1,method=c(2),control = list(maxit=30,M=c(20)))
                    LH=as.numeric(as.matrix(sol[[2]]))
                    sol=as.matrix(sol[[1]])
                    sol=as.numeric(sol[1:((Klink)),1])
                    Xi_=sol[1:length(sol)]
                    if(LH<oldLH){
                      oldXi_=Xi_

                    }
                  }
                }
              }
            }
          }
        }
      }
      end_time <- Sys.time()
      print(end_time-start_time)
      if(it==maxIt&redo_R){
        rho_check_s=oldrho_s*sum(Boxr)
        rho_check_s=rho_check_s-(Boxr[1])
        rho_check_s=10^(rho_check_s)
        rho_check_s=rho_check_s*Rho/theta

        rho_check=oldrho*sum(Boxr)
        rho_check=rho_check-(Boxr[1])
        rho_check=10^(rho_check)
        rho_check=rho_check*Rho/theta
        if(any(abs(rho_check_s-rho_check)>0.03)){
          print(rho_check_s)
          print(rho_check)
          print(abs(rho_check_s-rho_check))
          maxIt=maxIt+5
        }
      }
    }
    Vect=0:(k-1)
    Tc= window_scaling[2] -(log(1-(Vect/k))*(2-Self))/(2*(Beta^2)*window_scaling[1])
    res_t <- list();
    if(Popfix){
      rho_=oldrho*sum(Boxr)
      rho_=rho_-(Boxr[1])
      rho_=10^(rho_)
      rho_=rho_*Rho
      if(SB){
        beta=((oldbeta*(BoxB[2]-BoxB[1]))+BoxB[1] )^2
      }
      if(SF){
        sigma=oldsigma*(Boxs[2]-Boxs[1])
        sigma=sigma+Boxs[1]
      }
      if(NC==1){
        builder=build_HMM_matrix(k,(rho_),beta,L=L,Pop=Pop,Xi=NA,Beta,scale=window_scaling,sigma =sigma,Sigma = Self )
      }
      if(NC>1){
        if(Share_r){
          builder=build_HMM_matrix(k,(rho_[1]),beta,L=L[1],Pop=Pop,Xi=NA,Beta,scale=window_scaling,sigma =sigma,Sigma = Self )
        }else{
          builder=list()
          for(chr in 1:NC){
            builder[[chr]]=build_HMM_matrix(k,(rho_[chr]),beta,L=L[chr],Pop=Pop,Xi=NA,Beta,scale=window_scaling,sigma =sigma,Sigma = Self )
          }
        }
      }
    }
    if(!Popfix){
      xx=0
      for(ix in 1:Klink){
        x=xx+1
        xx = xx + pop_vect[ix]
        oldXi[x:xx]=oldXi_[ix]
      }
      Xi_=oldXi*sum(BoxP)
      Xi_=Xi_-(BoxP[1])
      Xi_=10^Xi_
      rho_=oldrho*sum(Boxr)
      rho_=rho_-(Boxr[1])
      rho_=10^(rho_)
      rho_=rho_*Rho
      if(SB){
        beta=((oldbeta*(BoxB[2]-BoxB[1]))+BoxB[1] )^2
      }
      if(SF){
        sigma=oldsigma*(Boxs[2]-Boxs[1])
        sigma=sigma+Boxs[1]
      }
      if(NC==1){
        builder=build_HMM_matrix(k,(rho_),beta,L=L,Pop=Pop,Xi_,Beta,scale=window_scaling,sigma =sigma,Sigma = Self)
      }
      if(NC>1){
        if(Share_r){
          builder=build_HMM_matrix(k,(rho_[1]),beta,L=L[1],Pop=Pop,Xi=Xi_,Beta,scale=window_scaling,sigma =sigma,Sigma = Self )
        }else{
          builder=list()
          for(chr in 1:NC){
            builder[[chr]]=build_HMM_matrix(k,(rho_[chr]),beta,L=L[chr],Pop=Pop,Xi=Xi_,Beta,scale=window_scaling,sigma =sigma,Sigma = Self )
          }
        }
      }
    }
    if(NC==1){
      Q = builder[[1]]
      nu= builder[[2]]
      Tc=builder[[3]]
      g=matrix(0,nrow=length(Tc),ncol=3)
      g[,2]=1-exp(-mu*2*Tc)
      g[,1]=exp(-mu*2*Tc)
      g[,3]=1
      Tc_r=builder[[4]]
    }
    if(NC>1){
      if(Share_r){
        Q = builder[[1]]
        nu= builder[[2]]
        Tc=builder[[3]]
        g=matrix(0,nrow=length(Tc),ncol=3)
        g[,2]=1-exp(-mu*2*Tc)
        g[,1]=exp(-mu*2*Tc)
        g[,3]=1
        Tc_r=builder[[4]]
      }else{
      Q=list()
      nu=list()
      Tc=list()
      Tc_r=list()
      g=list()
      for(chr in 1:NC){
        Q[[chr]] = builder[[chr]][[1]]
        nu[[chr]]= builder[[chr]][[2]]
        Tc[[chr]]=builder[[chr]][[3]]
        Tc_r[[chr]]=builder[[chr]][[4]]
        g[[chr]]=matrix(0,nrow=length(Tc[[chr]]),ncol=3)
        g[[chr]][,2]=1-exp(-mu[chr]*2*Tc[[chr]])
        g[[chr]][,1]=exp(-mu[chr]*2*Tc[[chr]])
        g[[chr]][,3]=1
      }
      }
    }
    res_t$LH<-LH
    res_t$Tc<-Tc_r
    Tc_or=Tc_r
    Tc_o=Tc
    if(!Popfix){
      Xi_t=oldXi_
      Xit=vector()
      pop_vect=get('pop_vect', envir=test.env)
      xx=0
      for(ix in 1:length(Xi_t)){
        x=xx+1
        xx = xx + pop_vect[ix]
        Xit[x:xx]=Xi_t[ix]
      }
      Xit=Xit*sum(BoxP)
      Xit=Xit-(BoxP[1])
      Xit=10^Xit
    }
    rho_t=oldrho*sum(Boxr)
    rho_t=rho_t-(Boxr[1])
    rho_t=10^(rho_t)
    rho_t=rho_t*Rho
    if(SB){
      beta=((oldbeta*(BoxB[2]-BoxB[1]))+BoxB[1] )^2
    }
    if(SF){
      sigma=oldsigma*(Boxs[2]-Boxs[1])
      sigma=sigma+Boxs[1]
    }
    if(!Popfix){
      res_t$Xi=Xit
    }
    res_t$mu<-mu
    res_t$beta=beta
    res_t$sigma=sigma
    rho_t=rho_t/(2*L)
    res_t$rho=rho_t
    res_t$Beta<- Beta
    res_t$Self<- Self
    old_list[[length(old_list)+1]]=res_t
    if(!SB){
      oldBeta=Beta
    }
    if(SB){
      oldBeta=Beta
      Beta=beta
    }
    if(SF){
      oldSelf=Self
      Self=sigma
    }
    if(!SF){
      oldSelf=Self
    }
    if(Beta==oldBeta&Self==oldSelf){
      mb=maxBit
      print("no need  for more iteration")
    }

  }
  if(NC==1){

    if(!restart){
      LH=0
      test=Build_zip_Matrix_mailund(Q,g,Os[[1]][[2]],nu)
      for(i in 1:length(Os)){
        fo=forward_zip_mailund(Os[[i]][[1]],g,nu,test[[1]])
        LH=LH+(sum(fo[[2]]))
      }
      res<-list()
      res$LH=LH
      res$Tc=Tc_or
      Q=t(Q)
      rho_=oldrho*sum(Boxr)
      rho_=rho_-(Boxr[1])
      rho_=10^(rho_)
      rho_=rho_*Rho
      rho_=rho_/(2*L)
      if(SB){
        beta=((oldbeta*(BoxB[2]-BoxB[1]))+BoxB[1] )^2
      }
      if(SF){
        sigma=oldsigma*(Boxs[2]-Boxs[1])
        sigma=sigma+Boxs[1]
      }
      if(!Popfix){
        res$Xi=Xi_
      }
      res$mu=mu
      res$L<-L
      res$beta=beta
      res$sigma=sigma
      res$rho=rho_
      res$Os<-Os

    }

    if(restart){
      res<-old_list[[length(old_list)]]
      res$Os<-Os
      res$old<-old_list
      res$L<-L
    }
  }
  if(NC>1){
    LH=0
    if(Share_r){
      test=Build_zip_Matrix_mailund(Q,g,Os[[1]][[1]][[2]],nu)
      for(chr in 1:NC){
        for(i in 1:length(Os[[chr]])){
          fo=forward_zip_mailund(Os[[chr]][[i]][[1]],g,nu,test[[1]])
          LH=LH+(sum(fo[[2]]))
        }
      }
    }else{
      for(chr in 1:NC){
      test=Build_zip_Matrix_mailund(Q[[chr]],g[[chr]],Os[[chr]][[1]][[2]],nu[[chr]])
      for(i in 1:length(Os[[chr]])){
        fo=forward_zip_mailund(Os[[chr]][[i]][[1]],g[[chr]],nu[[chr]],test[[1]])
        LH=LH+(sum(fo[[2]]))
      }
    }
    }

    res <- list();
    res$LH=LH
    if(Share_r){
      res$Tc=Tc_or
    }else{
      res$Tc=Tc_or[[1]]
    }
    res$L<-L
    rho_=oldrho*sum(Boxr)
    rho_=rho_-(Boxr[1])
    rho_=10^(rho_)
    rho_=rho_*Rho
    rho_=rho_/(2*L)
    if(SB){
      beta=((oldbeta*(BoxB[2]-BoxB[1]))+BoxB[1] )^2
    }
    if(SF){
      sigma=oldsigma*(Boxs[2]-Boxs[1])
      sigma=sigma+Boxs[1]
    }
    if(!Popfix){
      res$Xi=Xi_
    }
    res$beta=beta
    res$sigma=sigma
    res$rho=rho_
    res$mu=mu
    res$Os<-Os
  }
  return(res)
}
