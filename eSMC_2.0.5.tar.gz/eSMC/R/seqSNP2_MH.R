#' Build a signal for eSMC
#'
#' Takes a SNP matrix and build a sequence of 0 (two sequences are the same) and 1 (two sequences are difference)
#' @param DNA a segregating sites matrix of three lines. Nucleotides of individuals are on line 1 and 2 and their position on line 3
#' @param n length of the DNA sequence
#' @return : sequence of 0 and 1 (1 mutation, 0 no mutation)
seqSNP2_MH<-function(DNA,n){
  output=list()
  DNA=as.matrix(DNA)
  pos=which(DNA[1,]!=DNA[2,])
  seq=rep(2,n)
  seq[as.numeric(DNA[4,pos])]=1
  theta=length(pos)
  for(cc in 1:dim(DNA)[2]){
    if(cc==1){
      if(as.numeric(DNA[3,cc])>1){
        seq[1:(as.numeric(DNA[3,cc])-1)]=0
        #seq[as.numeric(sample(c(1:(as.numeric(DNA[4,cc])-1)),(as.numeric(DNA[3,cc])-1)))]=0
      }
    }else{
      if(as.numeric(DNA[3,(cc)])>1){
        seq[(as.numeric(DNA[4,(cc-1)])+1):(as.numeric(DNA[4,(cc-1)])+(as.numeric(DNA[3,cc])-1))]=0
        #seq[as.numeric(sample(c((as.numeric(DNA[4,(cc-1)])+1):(as.numeric(DNA[4,cc])-1)),(as.numeric(DNA[3,cc])-1)))]=0
      }
    }
  }
  seq=as.numeric(seq)
  n=length(which(as.numeric(seq)<2))
  theta=length(which(seq==1))/(n/length(seq))
  output$seq=as.numeric(seq)
  output$theta=as.numeric(theta)
  return(output)
}
