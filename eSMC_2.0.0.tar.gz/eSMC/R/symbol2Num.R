#'  Builds a numerical zip signal from the zip signal
#'
#' Transform the character sequence into a numeric vector
#' @param Os : original signal (sequence of 0 and 1)
#' @param Mat_symbol : Symbol matrix with the zipping pattern
#' @return A list with first object the ziped numerical sequence, as second the symbol matrix and as third the bp length of each symbol#
symbol2Num<-function(Os,Mat_symbol){
  output=list()
  for(zip_o in 1:2){
    if(length(as.numeric(Mat_symbol[[zip_o]]))>0){
      for(i in 1:dim(Mat_symbol[[zip_o]])[1]){
        sym=strsplit(Mat_symbol[[zip_o]][i,2],"")
        sym=sym[[1]]
        sym=paste(sym,collapse=" ")
        Mat_symbol[[zip_o]][i,2]=sym
      }
      count=0
      used_letters=vector()
      for( i in letters){
        if(any(Mat_symbol[[zip_o]][,1]%in%i)){
          used_letters=c(used_letters,i)
          count=count+1
          pos=which(Os%in%i)
          x=as.numeric(which(letters%in%i))
          Os[pos]=(10+(20*(zip_o-1)))+count
          Mat_symbol[[zip_o]][count,1]=(10+(20*(zip_o-1)))+count
          sym=strsplit(Mat_symbol[[zip_o]][count,2]," ")
          sym=sym[[1]]
          if(sym[1]%in%letters){
            sym[1]=(10+(20*(zip_o-1)))+as.numeric(which(used_letters==sym[1]))
          }
          if(sym[2]%in%letters){
            sym[2]=(10+(20*(zip_o-1)))+as.numeric(which(used_letters==sym[2]))
          }
          sym=paste(sym,collapse=" ")
          Mat_symbol[[zip_o]][count,2]=sym
        }
      }
    }
  }


  # output[[1]]=as.numeric(Os)
  #  output[[2]]=Mat_symbol
  mat_length=0:49
  mat_length=cbind(mat_length,rep(0,length(mat_length)))
  l=rep(0,50)
  l[1:2]=1
  for(oo in 1:2){
    if(length(as.numeric(Mat_symbol[[oo]]))>0){
      for(i in 1:dim(Mat_symbol[[oo]])[1]){
        sx=strsplit(Mat_symbol[[oo]][i,2]," ")
        sx=as.numeric(as.matrix(sx[[1]]))
        a=sx[1]
        b=sx[2]
        if(b<10){
          b=b+1
        }
        if(a<10){
          a=a+1
        }
        new_l=l[a]+l[b]
        l[as.numeric(Mat_symbol[[oo]][i,1])]=new_l
      }
    }
  }
  mat_length[,2]=l
  # output[[3]]=mat_length
  return(list(Os,Mat_symbol,mat_length))
}

